export type VoiceState = 'idle' | 'listening' | 'processing' | 'speaking';

export type AppTab = 'home' | 'reader' | 'tools' | 'chat';

export type InteractionMode = 'assistant' | 'reader';

export interface RealNoteItem {
  id: string;
  content: string;
  timestamp: string;
}

export interface ActionExecution {
  type:
    | 'open_youtube'
    | 'open_tiktok'
    | 'open_whatsapp'
    | 'make_call'
    | 'open_camera'
    | 'play_music'
    | 'save_note'
    | 'show_calculator'
    | 'open_google'
    | 'show_weather'
    | 'voice_read'
    | 'none';
  payload?: string;
  label: string;
  url?: string;
}

export interface MessageItem {
  id: string;
  sender: 'user' | 'nusu';
  text: string;
  timestamp: string;
  actionTaken?: string;
  mode?: InteractionMode;
}

export interface WeatherData {
  temp: number;
  condition: string;
  city: string;
  feelsLike: number;
  high: number;
  low: number;
  humidity: number;
  windSpeed?: string;
}

export interface MemoryItem {
  id: string;
  key: string;
  value: string;
  category: 'personal' | 'social' | 'preference' | 'system';
}

export interface NusuSettings {
  bossName: string;
  creatorName: string;
  language: 'auto' | 'bn-BD' | 'en-US';
  voiceSpeed: number;
  voicePitch: number;
  autoSpeak: boolean;
  hapticFeedback: boolean;
  defaultMode: InteractionMode;
}
