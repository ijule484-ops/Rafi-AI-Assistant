// Speech recognition & synthesis engine for Rafi Ai Assistant

interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
  resultIndex: number;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
  message?: string;
}

interface IWindowWithSpeech extends Window {
  SpeechRecognition?: any;
  webkitSpeechRecognition?: any;
}

class SpeechEngine {
  private recognitionInstance: any = null;
  private isListening: boolean = false;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private synth: SpeechSynthesis | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.synth = window.speechSynthesis || null;
    }
  }

  public isSupported(): boolean {
    if (typeof window === 'undefined') return false;
    const win = window as IWindowWithSpeech;
    return !!(win.SpeechRecognition || win.webkitSpeechRecognition);
  }

  public startListening(
    onResult: (text: string, isFinal: boolean) => void,
    onError: (error: string) => void,
    onEnd: () => void,
    lang: string = 'bn-BD'
  ): boolean {
    if (typeof window === 'undefined') return false;
    const win = window as IWindowWithSpeech;
    const SpeechRecognitionClass = win.SpeechRecognition || win.webkitSpeechRecognition;

    if (!SpeechRecognitionClass) {
      onError('ব্রাউজারে স্পিচ রিকগনিশন সাপোর্ট নেই। নিচের টেক্সট বক্সে লিখে কমান্ড দিন।');
      return false;
    }

    // Stop speaking if assistant was speaking
    this.stopSpeaking();

    // Abort previous recognition instance if running
    if (this.recognitionInstance) {
      try {
        this.recognitionInstance.abort();
      } catch {}
      this.recognitionInstance = null;
    }

    try {
      // Create a fresh instance for every session to avoid InvalidStateError in Chrome
      const recognition = new SpeechRecognitionClass();
      this.recognitionInstance = recognition;
      this.isListening = true;

      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;
      recognition.lang = lang || 'bn-BD';

      recognition.onresult = (event: SpeechRecognitionEvent) => {
        let transcript = '';
        let isFinal = false;

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const item = event.results[i];
          transcript += item[0].transcript;
          if (item.isFinal) {
            isFinal = true;
          }
        }

        onResult(transcript.trim(), isFinal);
      };

      recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
        this.isListening = false;
        if (event.error === 'not-allowed') {
          onError('মাইক্রোফোন পারমিশন পাওয়া যায়নি। ব্রাউজার সেটিংসে মাইক অন করুন।');
        } else if (event.error === 'no-speech') {
          onError('কোনো কথা শোনা যায়নি। আবার মাইক চেপে কথা বলুন।');
        } else if (event.error !== 'aborted') {
          onError(`ভয়েস ইনপুট সমস্যা: ${event.error}`);
        }
      };

      recognition.onend = () => {
        this.isListening = false;
        this.recognitionInstance = null;
        onEnd();
      };

      recognition.start();
      return true;
    } catch (e: any) {
      this.isListening = false;
      this.recognitionInstance = null;
      onError(e.message || 'মাইক্রোফোন চালু করতে সমস্যা হয়েছে');
      return false;
    }
  }

  public stopListening() {
    if (this.recognitionInstance) {
      try {
        this.recognitionInstance.stop();
      } catch {}
      this.recognitionInstance = null;
    }
    this.isListening = false;
  }

  public speak(
    text: string,
    options: {
      speed?: number;
      pitch?: number;
      lang?: string;
      onStart?: () => void;
      onEnd?: () => void;
      onError?: () => void;
    } = {}
  ) {
    if (!this.synth) {
      options.onEnd?.();
      return;
    }

    this.stopSpeaking();

    const cleanText = text
      .replace(/[*_#`~]/g, '')
      .replace(/OPEN_APP:\w+/gi, '')
      .replace(/NAVIGATE:\w+/gi, '')
      .replace(/SEND_MESSAGE:[^\n]+/gi, '')
      .trim();

    if (!cleanText) {
      options.onEnd?.();
      return;
    }

    const utterance = new SpeechSynthesisUtterance(cleanText);
    this.currentUtterance = utterance;

    utterance.rate = options.speed || 1.0;
    utterance.pitch = options.pitch || 1.15; // sweet clear pitch

    const voices = this.synth.getVoices();
    const targetLang = options.lang || 'bn-BD';

    const bnVoice = voices.find(
      (v) =>
        v.lang === 'bn-BD' ||
        v.lang === 'bn_BD' ||
        v.lang === 'bn-IN' ||
        v.lang === 'bn_IN' ||
        v.name.toLowerCase().includes('bangla') ||
        v.name.toLowerCase().includes('bengali')
    );

    const hiVoice = voices.find(
      (v) =>
        v.lang.startsWith('hi') ||
        v.name.toLowerCase().includes('india') ||
        v.name.toLowerCase().includes('neerja') ||
        v.name.toLowerCase().includes('swara')
    );

    if (bnVoice) {
      utterance.voice = bnVoice;
      utterance.lang = bnVoice.lang;
    } else if (hiVoice) {
      utterance.voice = hiVoice;
    } else {
      utterance.lang = targetLang;
    }

    utterance.onstart = () => {
      options.onStart?.();
    };

    utterance.onend = () => {
      this.currentUtterance = null;
      options.onEnd?.();
    };

    utterance.onerror = () => {
      this.currentUtterance = null;
      options.onError?.();
    };

    try {
      this.synth.speak(utterance);
    } catch {
      options.onEnd?.();
    }
  }

  public stopSpeaking() {
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch {}
      this.currentUtterance = null;
    }
  }

  public getAvailableVoices(): SpeechSynthesisVoice[] {
    if (!this.synth) return [];
    return this.synth.getVoices();
  }
}

export const speechEngine = new SpeechEngine();
