import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Volume2, Mic, Bot, User, Trash2 } from 'lucide-react';
import { MessageItem, VoiceState } from '../types';
import { playSound } from '../utils/soundEffects';

interface ChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  messages: MessageItem[];
  onSendMessage: (text: string) => void;
  onSpeakText: (text: string) => void;
  onClearHistory: () => void;
  voiceState: VoiceState;
  onStartVoice: () => void;
  bossName: string;
}

export const ChatDrawer: React.FC<ChatDrawerProps> = ({
  isOpen,
  onClose,
  messages,
  onSendMessage,
  onSpeakText,
  onClearHistory,
  voiceState,
  onStartVoice,
  bossName,
}) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(inputText.trim());
    setInputText('');
    playSound('pop');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md h-[88vh] max-h-[720px] rounded-3xl bg-[#0e0f1a] border border-purple-500/30 flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-purple-500/20 flex items-center justify-between bg-purple-950/20">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-purple-500 to-pink-500 flex items-center justify-center text-lg shadow-md">
              👻
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                Rafi Ai Assistant Conversation
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </h2>
              <p className="text-[10px] text-purple-300/70">
                Speaking with {bossName}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={onClearHistory}
              className="p-2 text-slate-400 hover:text-red-400 hover:bg-white/5 rounded-xl transition-all"
              title="Clear conversation"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-xl transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Message stream */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <span className="text-4xl mb-2 animate-bounce">👻</span>
              <p className="text-sm font-semibold text-slate-200">
                হ্যাঁ বস, আমি শুনছি!
              </p>
              <p className="text-xs text-purple-300/70 mt-1 max-w-[220px]">
                যেকোনো কথা বলুন বা লিখে পাঠান। আমি আপনার সব নির্দেশ পালন করবো।
              </p>
            </div>
          ) : (
            messages.map((m) => (
              <div
                key={m.id}
                className={`flex gap-2.5 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {m.sender === 'nusu' && (
                  <div className="w-7 h-7 rounded-xl bg-purple-600/30 border border-purple-400/30 flex items-center justify-center text-sm shrink-0 mt-0.5">
                    👻
                  </div>
                )}

                <div
                  className={`max-w-[80%] rounded-2xl p-3 text-xs leading-relaxed ${
                    m.sender === 'user'
                      ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-br-xs shadow-md'
                      : 'bg-white/5 border border-purple-500/20 text-slate-100 rounded-bl-xs'
                  }`}
                >
                  <div className="whitespace-pre-wrap">{m.text}</div>

                  {m.actionTaken && (
                    <div className="mt-1.5 pt-1.5 border-t border-white/10 flex items-center gap-1 text-[10px] text-cyan-300 font-mono">
                      <span>⚡ Action:</span>
                      <span className="bg-cyan-950/60 px-1.5 py-0.5 rounded text-cyan-200">
                        {m.actionTaken}
                      </span>
                    </div>
                  )}

                  <div className="flex items-center justify-between gap-3 mt-1.5 pt-1 text-[9px] opacity-70">
                    <span>{m.timestamp}</span>
                    {m.sender === 'nusu' && (
                      <button
                        onClick={() => onSpeakText(m.text)}
                        className="hover:text-pink-300 flex items-center gap-0.5"
                        title="Re-speak"
                      >
                        <Volume2 className="w-3 h-3" />
                        Listen
                      </button>
                    )}
                  </div>
                </div>

                {m.sender === 'user' && (
                  <div className="w-7 h-7 rounded-xl bg-indigo-600/40 border border-indigo-400/30 flex items-center justify-center text-xs shrink-0 mt-0.5">
                    <User className="w-3.5 h-3.5 text-indigo-200" />
                  </div>
                )}
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <form
          onSubmit={handleSubmit}
          className="p-3 border-t border-purple-500/20 bg-purple-950/20 flex items-center gap-2"
        >
          <button
            type="button"
            onClick={onStartVoice}
            className={`w-9 h-9 rounded-2xl flex items-center justify-center transition-all ${
              voiceState === 'listening'
                ? 'bg-cyan-500 text-black animate-pulse'
                : 'glass-panel text-purple-300 hover:text-white hover:bg-white/10'
            }`}
            title="Start voice input"
          >
            <Mic className="w-4 h-4" />
          </button>

          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={`Ask or tell Rafi Ai Assistant anything, ${bossName}...`}
            className="flex-1 bg-white/5 border border-purple-500/20 rounded-2xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-400"
          />

          <button
            type="submit"
            disabled={!inputText.trim()}
            className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-purple-600 to-pink-500 text-white flex items-center justify-center disabled:opacity-40 active:scale-95 transition-all shadow-md"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
