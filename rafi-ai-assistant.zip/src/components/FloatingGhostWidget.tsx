import React, { useState } from 'react';
import { Sparkles } from 'lucide-react';
import { VoiceState } from '../types';
import { playSound } from '../utils/soundEffects';

interface FloatingGhostWidgetProps {
  voiceState: VoiceState;
  onTap: () => void;
  spokenText: string;
  bossName: string;
}

export const FloatingGhostWidget: React.FC<FloatingGhostWidgetProps> = ({
  voiceState,
  onTap,
  spokenText,
  bossName,
}) => {
  const [showBubble, setShowBubble] = useState(true);

  return (
    <div className="fixed bottom-24 right-4 z-40 select-none">
      <div className="relative group flex items-end flex-col">
        {/* Spoken subtitle / tooltip bubble */}
        {spokenText && showBubble && (
          <div className="mb-2 max-w-[200px] p-2.5 rounded-2xl bg-[#0f0e1c]/95 border border-purple-500/40 text-[11px] text-purple-100 shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-2 leading-relaxed">
            <div className="flex items-center justify-between text-[9px] text-pink-400 font-bold uppercase tracking-wider mb-0.5">
              <span>👻 Rafi AI</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowBubble(false);
                }}
                className="text-slate-400 hover:text-white px-1"
              >
                ✕
              </button>
            </div>
            <p className="line-clamp-3">{spokenText}</p>
          </div>
        )}

        {/* Mascot Button */}
        <button
          onClick={() => {
            playSound('ghost');
            setShowBubble(true);
            onTap();
          }}
          className={`w-12 h-12 rounded-2xl glass-panel flex items-center justify-center text-2xl shadow-xl border border-purple-400/40 active:scale-90 transition-all ${
            voiceState === 'speaking'
              ? 'ring-2 ring-pink-400 animate-bounce shadow-pink-500/50 bg-purple-950/60'
              : voiceState === 'listening'
              ? 'ring-2 ring-cyan-400 animate-pulse shadow-cyan-500/50 bg-cyan-950/60'
              : 'animate-float bg-black/50 hover:bg-black/70'
          }`}
          title="Rafi AI Floating Companion - Tap to speak"
        >
          <span>👻</span>
        </button>
      </div>
    </div>
  );
};
