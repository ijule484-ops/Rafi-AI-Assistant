import React, { useState } from 'react';
import { X, Brain, Plus, Trash2, Sparkles, Check } from 'lucide-react';
import { MemoryItem } from '../types';
import { playSound } from '../utils/soundEffects';

interface MemoriesModalProps {
  isOpen: boolean;
  onClose: () => void;
  memories: MemoryItem[];
  onAddMemory: (key: string, value: string) => void;
  onDeleteMemory: (id: string) => void;
  onRecallVoice: () => void;
}

export const MemoriesModal: React.FC<MemoriesModalProps> = ({
  isOpen,
  onClose,
  memories,
  onAddMemory,
  onDeleteMemory,
  onRecallVoice,
}) => {
  const [newKey, setNewKey] = useState('');
  const [newValue, setNewValue] = useState('');

  if (!isOpen) return null;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey.trim() || !newValue.trim()) return;
    onAddMemory(newKey.trim(), newValue.trim());
    setNewKey('');
    setNewValue('');
    playSound('pop');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md rounded-3xl bg-[#0f101c] border border-pink-500/30 flex flex-col shadow-2xl overflow-hidden max-h-[85vh]">
        {/* Header */}
        <div className="p-4 border-b border-pink-500/20 flex items-center justify-between bg-pink-950/20">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center text-white shadow-md">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                Nūsu AI Memory Core
                <Sparkles className="w-3.5 h-3.5 text-pink-400" />
              </h2>
              <p className="text-[10px] text-pink-300/70">
                Persistent Knowledge & Personal Recall
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-xl transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1">
          {/* Quick Voice Recall Trigger */}
          <button
            onClick={onRecallVoice}
            className="w-full p-3 rounded-2xl bg-gradient-to-r from-pink-900/40 via-purple-900/40 to-indigo-900/40 border border-pink-400/30 flex items-center justify-between hover:scale-[1.01] active:scale-98 transition-all"
          >
            <div className="text-left">
              <span className="text-xs font-bold text-white block">
                🔊 ভয়েসে মেমোরি রিকল করুন
              </span>
              <span className="text-[10px] text-pink-200/70">
                নুসু এআই বস সম্পর্কে কি কি মনে রেখেছে জানুন
              </span>
            </div>
            <span className="text-xs bg-pink-500 text-white font-bold px-2 py-1 rounded-xl">
              Recall
            </span>
          </button>

          {/* Stored Memories List */}
          <div className="space-y-2">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              SAVED FACTS & KNOWLEDGE ({memories.length})
            </div>

            {memories.map((mem) => (
              <div
                key={mem.id}
                className="p-3 rounded-2xl glass-panel border border-purple-500/15 flex items-center justify-between group"
              >
                <div>
                  <span className="text-[10px] font-bold text-pink-300 tracking-wide uppercase block">
                    {mem.key}
                  </span>
                  <span className="text-xs text-slate-100 font-medium">
                    {mem.value}
                  </span>
                </div>
                <button
                  onClick={() => {
                    onDeleteMemory(mem.id);
                    playSound('pop');
                  }}
                  className="p-1.5 text-slate-500 hover:text-red-400 opacity-60 group-hover:opacity-100 transition-opacity"
                  title="Delete memory"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

          {/* Add new memory */}
          <form onSubmit={handleAdd} className="space-y-2 pt-2 border-t border-white/10">
            <span className="text-[11px] font-bold text-slate-400 block">
              নতুন তথ্য যোগ করুন:
            </span>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                placeholder="Topic (যেমন: প্রিয় গান)"
                value={newKey}
                onChange={(e) => setNewKey(e.target.value)}
                className="bg-white/5 border border-purple-500/20 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-pink-400"
              />
              <input
                type="text"
                placeholder="Value (যেমন: ঈশ্বরদী / রিল্যাক্সিং)"
                value={newValue}
                onChange={(e) => setNewValue(e.target.value)}
                className="bg-white/5 border border-purple-500/20 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-pink-400"
              />
            </div>
            <button
              type="submit"
              disabled={!newKey.trim() || !newValue.trim()}
              className="w-full py-2 rounded-xl bg-pink-600 hover:bg-pink-500 disabled:opacity-40 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md"
            >
              <Plus className="w-3.5 h-3.5" />
              মেমোরি সেভ করুন
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
