import React, { useState, useEffect, useRef } from 'react';
import { X, Play, Pause, Disc, SkipForward, SkipBack, Volume2, Sparkles, Music } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

interface RealMusicPlayerModalProps {
  isOpen: boolean;
  onClose: () => void;
  bossName: string;
}

export const RealMusicPlayerModal: React.FC<RealMusicPlayerModalProps> = ({
  isOpen,
  onClose,
  bossName,
}) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [volume, setVolume] = useState(0.7);
  const audioContextRef = useRef<AudioContext | null>(null);
  const timerRef = useRef<number | null>(null);

  const TRACKS = [
    { title: 'Ishq Sufiyana Melody', artist: 'Rafi & Sabbir Special', duration: '3:20' },
    { title: 'Acoustic Peace (শান্তির সুর)', artist: 'Bengali Flute & Chill', duration: '2:45' },
    { title: 'Cosmic Dream (মহাজাগতিক সুর)', artist: 'Rafi AI Soundscape', duration: '4:10' },
  ];

  // Synthesized harmonic musical arpeggios that play real audio in the browser!
  useEffect(() => {
    if (!isOpen) {
      stopMusic();
      return;
    }

    if (isPlaying) {
      startSynthesizedMusic();
    } else {
      stopMusic();
    }

    return () => {
      stopMusic();
    };
  }, [isOpen, isPlaying, currentTrackIndex]);

  const startSynthesizedMusic = () => {
    stopMusic();
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;

      // Chord sequences for tracks
      const chords = [
        [261.63, 329.63, 392.00, 523.25], // C Major
        [220.00, 261.63, 329.63, 440.00], // A Minor
        [174.61, 220.00, 261.63, 349.23], // F Major
        [196.00, 246.94, 293.66, 392.00], // G Major
      ];

      let chordIdx = 0;
      let noteIdx = 0;

      const playNextNote = () => {
        if (!audioContextRef.current || audioContextRef.current.state === 'closed') return;
        const currentChord = chords[chordIdx % chords.length];
        const freq = currentChord[noteIdx % currentChord.length];

        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = currentTrackIndex === 1 ? 'triangle' : 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);

        const noteVol = (volume * 0.12);
        gain.gain.setValueAtTime(0.001, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(noteVol, ctx.currentTime + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.38);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start();
        osc.stop(ctx.currentTime + 0.4);

        noteIdx++;
        if (noteIdx % 4 === 0) {
          chordIdx++;
        }

        timerRef.current = window.setTimeout(playNextNote, 220);
      };

      playNextNote();
    } catch (e) {
      console.warn('Audio synthesis error:', e);
    }
  };

  const stopMusic = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    if (audioContextRef.current) {
      try {
        audioContextRef.current.close();
      } catch {}
      audioContextRef.current = null;
    }
  };

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
    playSound('pop');
  };

  const nextTrack = () => {
    setCurrentTrackIndex((prev) => (prev + 1) % TRACKS.length);
    playSound('pop');
  };

  const prevTrack = () => {
    setCurrentTrackIndex((prev) => (prev - 1 + TRACKS.length) % TRACKS.length);
    playSound('pop');
  };

  if (!isOpen) return null;

  const currentTrack = TRACKS[currentTrackIndex];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md rounded-3xl bg-gradient-to-b from-[#180f29] via-[#0f0b18] to-[#09070e] border border-pink-500/30 flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-3.5 border-b border-pink-500/20 flex items-center justify-between bg-pink-950/20">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-pink-600/20 border border-pink-400/30 flex items-center justify-center text-pink-300">
              <Music className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xs font-bold text-white flex items-center gap-1.5">
                Rafi AI Music Player
                <Sparkles className="w-3 h-3 text-pink-400" />
              </h2>
              <p className="text-[10px] text-pink-300/70">
                {bossName} ভাইয়ের জন্য সরাসরি সুর প্লে হচ্ছে
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              stopMusic();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-white/5 rounded-xl transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Disc animation */}
        <div className="p-6 flex flex-col items-center justify-center space-y-4">
          <div className="relative w-44 h-44 rounded-full bg-gradient-to-tr from-pink-600 via-purple-600 to-cyan-500 p-1 shadow-2xl shadow-pink-600/30">
            <div
              className={`w-full h-full rounded-full bg-black flex items-center justify-center border-4 border-slate-900 ${
                isPlaying ? 'animate-spin-slow' : ''
              }`}
            >
              <Disc className="w-20 h-20 text-pink-400" />
            </div>
          </div>

          <div className="text-center space-y-1">
            <h3 className="text-base font-bold text-white tracking-wide">
              {currentTrack.title}
            </h3>
            <p className="text-xs text-pink-300/80 font-medium">
              {currentTrack.artist}
            </p>
          </div>

          {/* Audio Wave Visualizer bar */}
          <div className="flex items-center justify-center gap-1 h-8 py-1">
            {[40, 75, 100, 60, 85, 30, 90, 70, 50, 80, 65, 95].map((h, i) => (
              <div
                key={i}
                className={`w-1 rounded-full bg-gradient-to-t from-purple-500 to-pink-400 transition-all duration-300 ${
                  isPlaying ? 'animate-pulse' : 'opacity-40'
                }`}
                style={{ height: isPlaying ? `${h}%` : '20%' }}
              />
            ))}
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-6 pt-2">
            <button onClick={prevTrack} className="text-slate-400 hover:text-white active:scale-90 transition-transform">
              <SkipBack className="w-5 h-5" />
            </button>
            <button
              onClick={togglePlay}
              className="w-14 h-14 rounded-full bg-gradient-to-tr from-pink-600 to-purple-600 text-white flex items-center justify-center shadow-xl shadow-pink-600/40 active:scale-90 transition-transform"
            >
              {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-0.5" />}
            </button>
            <button onClick={nextTrack} className="text-slate-400 hover:text-white active:scale-90 transition-transform">
              <SkipForward className="w-5 h-5" />
            </button>
          </div>

          {/* Volume slider */}
          <div className="w-full flex items-center gap-2 pt-2 px-6">
            <Volume2 className="w-4 h-4 text-pink-300" />
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={volume}
              onChange={(e) => setVolume(parseFloat(e.target.value))}
              className="flex-1 accent-pink-500 cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
