import React from 'react';
import { Sun, CloudSun, Droplets, Wind, Sparkles } from 'lucide-react';
import { WeatherData } from '../types';

interface WeatherCardProps {
  weather: WeatherData;
  onAskWeather: () => void;
}

export const WeatherCard: React.FC<WeatherCardProps> = ({ weather, onAskWeather }) => {
  return (
    <div
      onClick={onAskWeather}
      role="button"
      tabIndex={0}
      title="Tap to hear weather report from Nūsu AI"
      className="w-full max-w-md mx-auto px-4 py-1"
    >
      <div className="glass-panel hover:bg-white/[0.08] active:scale-[0.99] transition-all rounded-3xl p-3.5 flex items-center justify-between shadow-lg shadow-purple-950/20 border border-purple-500/20 group cursor-pointer">
        {/* Left: Temperature */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400/20 to-orange-500/20 border border-amber-400/30 flex items-center justify-center text-amber-300 group-hover:scale-105 transition-transform">
            {weather.temp > 30 ? (
              <Sun className="w-6 h-6 animate-spin-slow text-amber-300" />
            ) : (
              <CloudSun className="w-6 h-6 text-amber-200" />
            )}
          </div>
          <div>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl font-extrabold tracking-tight text-white font-mono">
                {weather.temp}°C
              </span>
              <Sparkles className="w-3.5 h-3.5 text-pink-400 opacity-60" />
            </div>
            <div className="text-[11px] font-medium text-purple-300/80">
              {weather.city}
            </div>
          </div>
        </div>

        {/* Right: Condition & stats */}
        <div className="text-right">
          <div className="text-xs font-semibold text-white tracking-wide flex items-center justify-end gap-1">
            <span>{weather.condition}</span>
            <span className="text-purple-400">•</span>
            <span className="text-purple-200">{weather.city}</span>
          </div>
          <div className="text-[10px] text-purple-300/70 mt-1 flex items-center justify-end gap-2 font-mono">
            <span>Feels {weather.feelsLike}°</span>
            <span>H {weather.high}° L {weather.low}°</span>
            <span className="flex items-center gap-0.5">
              <Droplets className="w-2.5 h-2.5 text-cyan-400" />
              {weather.humidity}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
