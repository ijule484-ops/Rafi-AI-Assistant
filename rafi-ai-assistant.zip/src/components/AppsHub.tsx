import React from 'react';
import {
  Youtube,
  Phone,
  Camera,
  Music,
  FileText,
  Calculator,
  Search,
  Sparkles,
  CloudSun,
  Smile,
  BookOpen,
  Send,
  ExternalLink,
} from 'lucide-react';
import { playSound } from '../utils/soundEffects';

interface AppsHubProps {
  onTriggerCommand: (cmd: string) => void;
  onOpenMusic: () => void;
  onOpenCamera: () => void;
  onOpenNotes: () => void;
  bossName: string;
}

export const AppsHub: React.FC<AppsHubProps> = ({
  onTriggerCommand,
  onOpenMusic,
  onOpenCamera,
  onOpenNotes,
  bossName,
}) => {
  const APPS = [
    {
      id: 'youtube',
      name: 'YouTube',
      desc: 'ভিডিও ও গান',
      icon: <Youtube className="w-6 h-6 text-red-500" />,
      bg: 'bg-red-500/10 border-red-500/20 hover:border-red-500/40',
      action: () => onTriggerCommand('ইউটিউব খোলো'),
    },
    {
      id: 'music',
      name: 'Music Player',
      desc: 'সরাসরি গান প্লে',
      icon: <Music className="w-6 h-6 text-pink-400" />,
      bg: 'bg-pink-500/10 border-pink-500/20 hover:border-pink-500/40',
      action: onOpenMusic,
    },
    {
      id: 'tiktok',
      name: 'TikTok',
      desc: 'ভিডিও ও ইনবক্স',
      icon: <span className="text-xl font-black text-cyan-400">d</span>,
      bg: 'bg-cyan-500/10 border-cyan-500/20 hover:border-cyan-500/40',
      action: () => onTriggerCommand('টিকটক ওপেন করো'),
    },
    {
      id: 'whatsapp',
      name: 'WhatsApp',
      desc: 'চ্যাট ও মেসেজ',
      icon: <Phone className="w-6 h-6 text-emerald-400" />,
      bg: 'bg-emerald-500/10 border-emerald-500/20 hover:border-emerald-500/40',
      action: () => onTriggerCommand('হোয়াটসঅ্যাপ খোলো'),
    },
    {
      id: 'call',
      name: 'ফোন কল (সাব্বির)',
      desc: 'সরাসরি ডায়াল',
      icon: <Phone className="w-6 h-6 text-green-400" />,
      bg: 'bg-green-500/10 border-green-500/20 hover:border-green-500/40',
      action: () => onTriggerCommand('সাব্বিরকে কল দাও'),
    },
    {
      id: 'camera',
      name: 'ক্যামেরা',
      desc: 'আসল ক্যামেরা',
      icon: <Camera className="w-6 h-6 text-cyan-300" />,
      bg: 'bg-cyan-500/10 border-cyan-500/20 hover:border-cyan-500/40',
      action: onOpenCamera,
    },
    {
      id: 'notes',
      name: 'নোট ও ডায়েরি',
      desc: 'সেভ করা নোটস',
      icon: <FileText className="w-6 h-6 text-amber-400" />,
      bg: 'bg-amber-500/10 border-amber-500/20 hover:border-amber-500/40',
      action: onOpenNotes,
    },
    {
      id: 'calculator',
      name: 'ক্যালকুলেটর',
      desc: 'হিসাব-নিকাশ',
      icon: <Calculator className="w-6 h-6 text-indigo-400" />,
      bg: 'bg-indigo-500/10 border-indigo-500/20 hover:border-indigo-500/40',
      action: () => onTriggerCommand('৫০ গুণ ১০ কত?'),
    },
    {
      id: 'joke',
      name: 'কৌতুক / জোকস',
      desc: 'হাসির গল্প',
      icon: <Smile className="w-6 h-6 text-yellow-400" />,
      bg: 'bg-yellow-500/10 border-yellow-500/20 hover:border-yellow-500/40',
      action: () => onTriggerCommand('একটা মজার কৌতুক বলো'),
    },
    {
      id: 'story',
      name: 'গল্প পাঠ',
      desc: 'শিক্ষণীয় গল্প',
      icon: <BookOpen className="w-6 h-6 text-purple-400" />,
      bg: 'bg-purple-500/10 border-purple-500/20 hover:border-purple-500/40',
      action: () => onTriggerCommand('একটি শিক্ষণীয় গল্প বলো'),
    },
    {
      id: 'weather',
      name: 'আবহাওয়া',
      desc: 'মাধবপুর লাইভ',
      icon: <CloudSun className="w-6 h-6 text-orange-400" />,
      bg: 'bg-orange-500/10 border-orange-500/20 hover:border-orange-500/40',
      action: () => onTriggerCommand('আজকের আবহাওয়া কেমন?'),
    },
    {
      id: 'google',
      name: 'গুগল সার্চ',
      desc: 'যেকোনো তথ্য',
      icon: <Search className="w-6 h-6 text-blue-400" />,
      bg: 'bg-blue-500/10 border-blue-500/20 hover:border-blue-500/40',
      action: () => onTriggerCommand('গুগলে সার্চ করো আজকের খবর'),
    },
  ];

  return (
    <div className="w-full max-w-md mx-auto px-4 py-2 space-y-3 select-none">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
            Rafi AI Mobile Apps & Actions
            <Sparkles className="w-4 h-4 text-pink-400" />
          </h2>
          <p className="text-[11px] text-purple-300/70">
            {bossName} ভাইয়ের ফোনের আসল টুলস ও অ্যাপ সেন্টার
          </p>
        </div>
      </div>

      {/* Grid of real mobile action cards */}
      <div className="grid grid-cols-2 gap-2.5">
        {APPS.map((app) => (
          <button
            key={app.id}
            onClick={() => {
              playSound('pop');
              app.action();
            }}
            className={`p-3 rounded-2xl border ${app.bg} flex items-center gap-3 text-left transition-all active:scale-95 shadow-md`}
          >
            <div className="p-2 rounded-xl bg-white/5 border border-white/10 shrink-0">
              {app.icon}
            </div>
            <div className="min-w-0">
              <span className="text-xs font-bold text-white block truncate">
                {app.name}
              </span>
              <span className="text-[10px] text-slate-400 block truncate">
                {app.desc}
              </span>
            </div>
          </button>
        ))}
      </div>

      {/* Quick Voice Command Tips for Mobile */}
      <div className="glass-panel rounded-2xl p-3 border border-purple-500/20 space-y-1.5 text-xs text-slate-300">
        <span className="font-bold text-purple-300 block text-[11px] uppercase tracking-wider">
          💡 আপনি মুখে যা যা বলতে পারেন:
        </span>
        <div className="grid grid-cols-1 gap-1 text-[11px] text-purple-200/80">
          <div>• "ইউটিউব খোলো" ➔ সরাসরি ইউটিউবে নিয়ে যাবে</div>
          <div>• "গান বাজাও" ➔ সুরের গান শুরু করবে</div>
          <div>• "সাব্বিরকে কল দাও" ➔ ফোন ডায়ালার ওপেন করবে</div>
          <div>• "ক্যামেরা অন করো" ➔ আসল ক্যামেরা চালু করবে</div>
          <div>• "নোট লেখো: [আপনার কথা]" ➔ নোটপ্যাডে সেভ করবে</div>
        </div>
      </div>
    </div>
  );
};
