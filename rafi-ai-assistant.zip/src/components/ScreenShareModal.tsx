import React, { useState, useRef } from 'react';
import { X, ScreenShare, Sparkles, Eye, Loader2, Camera, Check } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

interface ScreenShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAnalyzeScreen: (imageBase64: string, question?: string) => Promise<void>;
  isAnalyzing: boolean;
  bossName: string;
}

export const ScreenShareModal: React.FC<ScreenShareModalProps> = ({
  isOpen,
  onClose,
  onAnalyzeScreen,
  isAnalyzing,
  bossName,
}) => {
  const [streamActive, setStreamActive] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const videoRef = useRef<HTMLVideoElement | null>(null);

  if (!isOpen) return null;

  const handleStartRealScreenShare = async () => {
    try {
      setErrorMsg('');
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { displaySurface: 'browser' },
        audio: false,
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        setStreamActive(true);
        playSound('action');
      }
    } catch (err: any) {
      console.warn('Screen share cancelled or not supported:', err);
      setErrorMsg('স্ক্রিন শেয়ার পারমিশন পাওয়া যায়নি বা বাতিল করা হয়েছে। নিচের ডেমো স্ক্রিন দিয়ে ট্রাই করুন।');
    }
  };

  const handleCaptureAndInspect = async () => {
    if (!videoRef.current) return;
    try {
      const video = videoRef.current;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
      await onAnalyzeScreen(dataUrl, 'এই স্ক্রিনে কি দেখা যাচ্ছে এবং কি কাজ করতে হবে?');
    } catch (err: any) {
      setErrorMsg('স্ক্রিন ক্যাপচার ব্যর্থ হয়েছে।');
    }
  };

  const handleInspectDemoScreen = async () => {
    // Generate a simulated screen frame representing Sabbir's TikTok chat
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 800;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Dark TikTok chat mock
    ctx.fillStyle = '#0f0f18';
    ctx.fillRect(0, 0, 600, 800);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 24px sans-serif';
    ctx.fillText('TikTok Inbox • Sabbir', 40, 60);

    ctx.fillStyle = '#27273a';
    ctx.roundRect(40, 100, 480, 80, 16);
    ctx.fill();
    ctx.fillStyle = '#f1f5f9';
    ctx.font = '20px sans-serif';
    ctx.fillText('তোমার whatsapp number dao video ta di...', 60, 145);

    ctx.fillStyle = '#9333ea';
    ctx.roundRect(200, 220, 360, 70, 16);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.fillText('Ok ok fast korchi', 230, 260);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    await onAnalyzeScreen(dataUrl, 'স্ক্রিনের মেসেজ দেখে সাব্বির কি চাইছে বলো');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md rounded-3xl bg-[#0f101d] border border-cyan-500/30 flex flex-col shadow-2xl overflow-hidden max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-cyan-500/20 flex items-center justify-between bg-cyan-950/20">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md">
              <ScreenShare className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                Nūsu AI Screen Companion
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              </h2>
              <p className="text-[10px] text-cyan-300/70">
                Visual Assistant & Multimodal Screen Inspection
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-xl transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 space-y-4 overflow-y-auto">
          <p className="text-xs text-slate-300 leading-relaxed">
            ভিডিওতে যেভাবে নুসু এআই বসের ফোনের স্ক্রিন দেখে নির্দেশ পালন করে,
            আপনি আপনার নিজের কম্পিউটার/ফোনের স্ক্রিন শেয়ার করে নুসুকে দেখতে বলতে পারেন!
          </p>

          {/* Video preview or placeholder */}
          <div className="relative rounded-2xl bg-black border border-cyan-500/20 overflow-hidden min-h-[180px] flex items-center justify-center">
            <video
              ref={videoRef}
              className={`w-full h-auto max-h-[240px] object-contain ${streamActive ? 'block' : 'hidden'}`}
              autoPlay
              playsInline
              muted
            />

            {!streamActive && (
              <div className="text-center p-6 space-y-2">
                <Eye className="w-10 h-10 text-cyan-400/60 mx-auto animate-pulse" />
                <p className="text-xs text-slate-400">
                  স্ক্রিন শেয়ার শুরু করতে নিচের বাটনে চাপ দিন
                </p>
              </div>
            )}
          </div>

          {errorMsg && (
            <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-500/30 text-[11px] text-amber-200">
              {errorMsg}
            </div>
          )}

          {/* Action buttons */}
          <div className="space-y-2">
            {!streamActive ? (
              <button
                onClick={handleStartRealScreenShare}
                className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-950/40 active:scale-98 transition-all"
              >
                <ScreenShare className="w-4 h-4" />
                লাইভ স্ক্রিন শেয়ার শুরু করুন
              </button>
            ) : (
              <button
                onClick={handleCaptureAndInspect}
                disabled={isAnalyzing}
                className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-lg active:scale-98 transition-all disabled:opacity-50"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    নুসু স্ক্রিন দেখছে...
                  </>
                ) : (
                  <>
                    <Eye className="w-4 h-4" />
                    নুসুকে স্ক্রিন বিশ্লেষণ করতে বলুন
                  </>
                )}
              </button>
            )}

            {/* Instant Demo Screen inspect */}
            <button
              onClick={handleInspectDemoScreen}
              disabled={isAnalyzing}
              className="w-full py-2.5 rounded-2xl glass-panel hover:bg-white/10 text-cyan-200 font-semibold text-xs flex items-center justify-center gap-2 border border-cyan-500/30 active:scale-98 transition-all"
            >
              <Sparkles className="w-4 h-4 text-pink-400" />
              ডেমো টিকটক স্ক্রিন বিশ্লেষণ টেস্ট (ভিডিওর মতো)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
