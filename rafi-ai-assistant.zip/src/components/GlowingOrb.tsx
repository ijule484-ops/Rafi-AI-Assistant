import React, { useEffect, useRef } from 'react';
import { VoiceState } from '../types';

interface GlowingOrbProps {
  state: VoiceState;
  onClick: () => void;
  size?: number;
}

export const GlowingOrb: React.FC<GlowingOrbProps> = ({ state, onClick, size = 260 }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let time = 0;

    // Particle cloud settings
    const numParticles = 240;
    const particles: Array<{
      baseRadius: number;
      angle: number;
      speed: number;
      size: number;
      color: string;
      phase: number;
    }> = [];

    const palette = [
      '#a855f7', // purple
      '#ec4899', // pink
      '#38bdf8', // sky cyan
      '#c084fc', // light purple
      '#818cf8', // indigo
      '#f472b6', // rose
    ];

    for (let i = 0; i < numParticles; i++) {
      particles.push({
        baseRadius: 35 + Math.random() * 65,
        angle: Math.random() * Math.PI * 2,
        speed: (Math.random() - 0.5) * 0.015,
        size: 1 + Math.random() * 2.2,
        color: palette[Math.floor(Math.random() * palette.length)],
        phase: Math.random() * Math.PI * 2,
      });
    }

    const render = () => {
      time += 0.025;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;

      // Dynamics based on state
      let pulseMultiplier = 1;
      let waveSpeed = 1;

      if (state === 'speaking') {
        pulseMultiplier = 1 + Math.sin(time * 6) * 0.12 + Math.cos(time * 3) * 0.06;
        waveSpeed = 2.2;
      } else if (state === 'listening') {
        pulseMultiplier = 1 + Math.sin(time * 4) * 0.08;
        waveSpeed = 1.6;
      } else if (state === 'processing') {
        pulseMultiplier = 1 + Math.sin(time * 10) * 0.05;
        waveSpeed = 3.5;
      } else {
        // Idle gentle breathing
        pulseMultiplier = 1 + Math.sin(time * 1.5) * 0.03;
        waveSpeed = 0.8;
      }

      // Draw subtle outer glow ring
      const outerGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        20,
        centerX,
        centerY,
        110 * pulseMultiplier
      );
      if (state === 'listening') {
        outerGrad.addColorStop(0, 'rgba(56, 189, 248, 0.35)');
        outerGrad.addColorStop(0.5, 'rgba(168, 85, 247, 0.2)');
        outerGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      } else if (state === 'speaking') {
        outerGrad.addColorStop(0, 'rgba(236, 72, 153, 0.4)');
        outerGrad.addColorStop(0.5, 'rgba(192, 132, 252, 0.25)');
        outerGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      } else if (state === 'processing') {
        outerGrad.addColorStop(0, 'rgba(245, 158, 11, 0.35)');
        outerGrad.addColorStop(0.6, 'rgba(168, 85, 247, 0.2)');
        outerGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      } else {
        outerGrad.addColorStop(0, 'rgba(168, 85, 247, 0.25)');
        outerGrad.addColorStop(0.6, 'rgba(56, 189, 248, 0.1)');
        outerGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      }

      ctx.fillStyle = outerGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, 110 * pulseMultiplier, 0, Math.PI * 2);
      ctx.fill();

      // Render glowing concentric sonic rings
      for (let ring = 0; ring < 3; ring++) {
        const ringRadius = (55 + ring * 22) * pulseMultiplier;
        ctx.beginPath();
        ctx.arc(centerX, centerY, ringRadius, 0, Math.PI * 2);
        ctx.strokeStyle =
          state === 'speaking'
            ? `rgba(236, 72, 153, ${0.15 - ring * 0.03})`
            : state === 'listening'
            ? `rgba(56, 189, 248, ${0.2 - ring * 0.04})`
            : `rgba(168, 85, 247, ${0.12 - ring * 0.02})`;
        ctx.lineWidth = 1.2;
        ctx.stroke();
      }

      // Draw particle constellation
      particles.forEach((p) => {
        p.angle += p.speed * waveSpeed;
        const wave = Math.sin(time * 3 + p.phase) * (state === 'speaking' ? 9 : 4);
        const curRadius = (p.baseRadius + wave) * pulseMultiplier;

        const x = centerX + Math.cos(p.angle) * curRadius;
        const y = centerY + Math.sin(p.angle) * curRadius;

        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(x, y, p.size * (state === 'speaking' ? 1.2 : 1), 0, Math.PI * 2);
        ctx.fill();
      });

      // Core energetic sphere
      const coreGrad = ctx.createRadialGradient(
        centerX - 8,
        centerY - 8,
        4,
        centerX,
        centerY,
        45 * pulseMultiplier
      );
      if (state === 'speaking') {
        coreGrad.addColorStop(0, '#ffffff');
        coreGrad.addColorStop(0.3, '#f472b6');
        coreGrad.addColorStop(0.7, '#c084fc');
        coreGrad.addColorStop(1, 'rgba(168, 85, 247, 0)');
      } else if (state === 'listening') {
        coreGrad.addColorStop(0, '#ffffff');
        coreGrad.addColorStop(0.3, '#38bdf8');
        coreGrad.addColorStop(0.7, '#818cf8');
        coreGrad.addColorStop(1, 'rgba(56, 189, 248, 0)');
      } else {
        coreGrad.addColorStop(0, '#ffffff');
        coreGrad.addColorStop(0.3, '#e9d5ff');
        coreGrad.addColorStop(0.7, '#a855f7');
        coreGrad.addColorStop(1, 'rgba(168, 85, 247, 0)');
      }

      ctx.fillStyle = coreGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, 45 * pulseMultiplier, 0, Math.PI * 2);
      ctx.fill();

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [state]);

  return (
    <div
      onClick={onClick}
      role="button"
      tabIndex={0}
      aria-label="Nūsu AI Voice Orb"
      className="relative flex items-center justify-center cursor-pointer select-none transition-transform duration-300 hover:scale-105 active:scale-95 group"
      style={{ width: size, height: size }}
    >
      {/* Outer ambient blur aura */}
      <div
        className={`absolute inset-4 rounded-full blur-2xl transition-all duration-700 pointer-events-none ${
          state === 'speaking'
            ? 'bg-gradient-to-tr from-pink-500/40 via-purple-600/40 to-cyan-400/40 scale-110'
            : state === 'listening'
            ? 'bg-gradient-to-tr from-cyan-400/40 via-blue-500/40 to-purple-500/40 scale-105'
            : state === 'processing'
            ? 'bg-gradient-to-tr from-amber-400/30 via-purple-500/30 to-pink-500/30 animate-spin-slow'
            : 'bg-gradient-to-tr from-purple-600/25 via-indigo-500/20 to-pink-500/25'
        }`}
      />

      {/* Orbit ring SVG */}
      <svg
        className={`absolute inset-0 w-full h-full pointer-events-none transition-transform duration-1000 ${
          state === 'speaking' ? 'animate-spin-slow' : 'opacity-80'
        }`}
        viewBox="0 0 260 260"
      >
        <circle
          cx="130"
          cy="130"
          r="105"
          fill="none"
          stroke="url(#orbRingGradient)"
          strokeWidth="1.5"
          strokeDasharray="6 8"
          className="opacity-60"
        />
        <defs>
          <linearGradient id="orbRingGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#38bdf8" />
            <stop offset="50%" stopColor="#c084fc" />
            <stop offset="100%" stopColor="#f472b6" />
          </linearGradient>
        </defs>
      </svg>

      {/* Canvas particle renderer */}
      <canvas
        ref={canvasRef}
        width={size}
        height={size}
        className="relative z-10 w-full h-full"
      />
    </div>
  );
};
