import React from 'react';
import { ExternalLink, CheckCircle2, X } from 'lucide-react';
import { ActionExecution } from '../types';
import { playSound } from '../utils/soundEffects';

interface ActionBannerProps {
  action: ActionExecution | null;
  onDismiss: () => void;
}

export const ActionBanner: React.FC<ActionBannerProps> = ({ action, onDismiss }) => {
  if (!action || action.type === 'none') return null;

  const handleOpenLink = () => {
    playSound('action');
    if (action.url) {
      if (action.url.startsWith('tel:')) {
        window.location.href = action.url;
      } else {
        window.open(action.url, '_blank', 'noopener,noreferrer');
      }
    }
  };

  return (
    <div className="w-full max-w-md mx-auto px-4 py-1.5 animate-in slide-in-from-top-2 duration-300">
      <div className="rounded-2xl bg-gradient-to-r from-purple-900/90 via-indigo-900/90 to-pink-900/90 border border-purple-400/40 p-3 shadow-xl shadow-purple-950/40 backdrop-blur-md flex items-center justify-between gap-3 text-white">
        <div className="flex items-center gap-2.5 flex-1 min-w-0">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 animate-pulse" />
          <div className="min-w-0">
            <span className="text-xs font-bold block truncate text-slate-100">
              {action.label}
            </span>
            <span className="text-[10px] text-purple-200/70 block truncate">
              {action.payload || 'অ্যাকশন সফলভাবে কার্যকর হয়েছে'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {action.url && (
            <button
              onClick={handleOpenLink}
              className="px-2.5 py-1.5 rounded-xl bg-white text-purple-950 font-bold text-[11px] shadow-md flex items-center gap-1 active:scale-95 transition-transform"
            >
              <span>প্রবেশ করুন</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          )}

          <button
            onClick={onDismiss}
            className="p-1 text-purple-200 hover:text-white rounded-lg hover:bg-white/10"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
