import React from 'react';
import { X, Settings as SettingsIcon, Volume2, User, Globe, Sparkles, Check } from 'lucide-react';
import { NusuSettings } from '../types';
import { playSound } from '../utils/soundEffects';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: NusuSettings;
  onUpdateSettings: (newSettings: Partial<NusuSettings>) => void;
  onTestVoice: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onTestVoice,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md rounded-3xl bg-[#0e0f1a] border border-purple-500/30 flex flex-col shadow-2xl overflow-hidden max-h-[85vh]">
        {/* Header */}
        <div className="p-4 border-b border-purple-500/20 flex items-center justify-between bg-purple-950/20">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-md">
              <SettingsIcon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                Rafi Ai Assistant Settings
              </h2>
              <p className="text-[10px] text-purple-300/70">
                Voice, Persona & Assistant Preferences
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-xl transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-4 text-xs">
          {/* Boss Name */}
          <div className="space-y-1.5">
            <label className="font-bold text-slate-300 flex items-center gap-1.5">
              <User className="w-4 h-4 text-purple-400" />
              বস সম্বোধন (Boss Name):
            </label>
            <input
              type="text"
              value={settings.bossName}
              onChange={(e) => onUpdateSettings({ bossName: e.target.value })}
              placeholder="e.g. রাফি, Rafi Boss, বস"
              className="w-full bg-white/5 border border-purple-500/20 rounded-xl px-3.5 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-purple-400 font-medium"
            />
            <p className="text-[10px] text-purple-300/60">
              রাফি এআই আপনাকে সবসময় এই নামে সম্মান জানিয়ে সম্বোধন করবে।
            </p>
          </div>

          {/* Voice Pitch (Feminine / Sweet tone) */}
          <div className="space-y-1.5 pt-2 border-t border-white/5">
            <div className="flex justify-between items-center font-bold text-slate-300">
              <span className="flex items-center gap-1.5">
                <Volume2 className="w-4 h-4 text-pink-400" />
                কণ্ঠের স্বর (Voice Pitch):
              </span>
              <span className="text-pink-300 font-mono">{settings.voicePitch.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="0.8"
              max="1.5"
              step="0.05"
              value={settings.voicePitch}
              onChange={(e) => onUpdateSettings({ voicePitch: parseFloat(e.target.value) })}
              className="w-full accent-pink-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>গম্ভীর</span>
              <span>স্বাভাবিক</span>
              <span>মিষ্টি / উচ্চ (ভিডিওর মতো)</span>
            </div>
          </div>

          {/* Voice Speed */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center font-bold text-slate-300">
              <span>কথা বলার গতি (Speed):</span>
              <span className="text-purple-300 font-mono">{settings.voiceSpeed.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="0.8"
              max="1.3"
              step="0.05"
              value={settings.voiceSpeed}
              onChange={(e) => onUpdateSettings({ voiceSpeed: parseFloat(e.target.value) })}
              className="w-full accent-purple-500 cursor-pointer"
            />
          </div>

          {/* Language Mode */}
          <div className="space-y-1.5 pt-2 border-t border-white/5">
            <label className="font-bold text-slate-300 flex items-center gap-1.5">
              <Globe className="w-4 h-4 text-cyan-400" />
              ভাষা মোড (Language Mode):
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'auto', label: 'Auto (স্বয়ংক্রিয়)' },
                { id: 'bn-BD', label: 'বাংলা (Bengali)' },
                { id: 'en-US', label: 'English' },
              ].map((lang) => (
                <button
                  key={lang.id}
                  onClick={() => onUpdateSettings({ language: lang.id as any })}
                  className={`p-2 rounded-xl text-center border transition-all ${
                    settings.language === lang.id
                      ? 'bg-purple-600/40 border-purple-400 text-white font-bold'
                      : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                  }`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
          </div>

          {/* Auto Speak Toggle */}
          <div className="pt-2 border-t border-white/5 flex items-center justify-between">
            <div>
              <span className="font-bold text-slate-200 block">
                স্বয়ংক্রিয় ভয়েস আউটপুট (Auto Speak)
              </span>
              <span className="text-[10px] text-slate-400">
                নুসু নিজে থেকে মুখে কথা বলে উত্তর দেবে
              </span>
            </div>
            <button
              onClick={() => onUpdateSettings({ autoSpeak: !settings.autoSpeak })}
              className={`w-12 h-6 rounded-full transition-colors p-1 flex items-center ${
                settings.autoSpeak ? 'bg-purple-600 justify-end' : 'bg-slate-700 justify-start'
              }`}
            >
              <div className="w-4 h-4 rounded-full bg-white shadow-sm" />
            </button>
          </div>

          {/* Test Voice Button */}
          <div className="pt-3">
            <button
              onClick={onTestVoice}
              className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 text-white font-semibold flex items-center justify-center gap-2 shadow-lg shadow-purple-950/40 active:scale-98 transition-all"
            >
              <Volume2 className="w-4 h-4" />
              কণ্ঠ টেস্ট শুনুন (ভিডিওর মতো ডায়ালগ)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
