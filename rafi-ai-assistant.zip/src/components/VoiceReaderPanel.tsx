import React, { useState } from 'react';
import { Volume2, Mic, Play, Pause, RotateCcw, Copy, Check, Sparkles, BookOpen } from 'lucide-react';
import { InteractionMode, VoiceState } from '../types';
import { playSound } from '../utils/soundEffects';

interface VoiceReaderPanelProps {
  onSpeakText: (text: string) => void;
  voiceState: VoiceState;
  currentMode: InteractionMode;
  onToggleMode: (mode: InteractionMode) => void;
  bossName: string;
}

const PRESET_PHRASES = [
  'হ্যালো রাফি ভাই, আমি আপনার রাফি এআই অ্যাসিস্ট্যান্ট। আপনি যা বলবেন আমি তাই পড়ে শোনাবো।',
  'আজকের দিনটি অনেক সুন্দর এবং আনন্দময় কাটুক সবার!',
  'জ্ঞানই শক্তি, আর পরিশ্রমই সাফল্যের চাবিকাঠি।',
  'অসংখ্য ধন্যবাদ ভাইয়া, ভিডিওটি তৈরি করে সাপোর্ট করার জন্য!',
  'তোমার হোয়াটসঅ্যাপ নাম্বার দাও, ভিডিওটা পাঠাচ্ছি।',
];

export const VoiceReaderPanel: React.FC<VoiceReaderPanelProps> = ({
  onSpeakText,
  voiceState,
  currentMode,
  onToggleMode,
  bossName,
}) => {
  const [customText, setCustomText] = useState(
    'হ্যালো রাফি ভাই, আমি আপনার রাফি এআই অ্যাসিস্ট্যান্ট। আপনি যা বলবেন আমি তাই পড়ে শোনাবো।'
  );
  const [copied, setCopied] = useState(false);

  const handleSpeak = () => {
    if (!customText.trim()) return;
    playSound('pop');
    onSpeakText(customText.trim());
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(customText);
    setCopied(true);
    playSound('pop');
    setTimeout(() => setCopied(false), 1500);
  };

  const handleClear = () => {
    setCustomText('');
    playSound('pop');
  };

  return (
    <div className="w-full max-w-md mx-auto px-4 py-2 select-none">
      <div className="glass-panel rounded-3xl p-4 border border-purple-500/25 shadow-xl shadow-purple-950/20 space-y-3">
        {/* Header & Mode Switcher */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center text-white shadow-md">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-white block flex items-center gap-1">
                ভয়েস রিডার মোড
                <Sparkles className="w-3 h-3 text-pink-400" />
              </span>
              <span className="text-[10px] text-purple-300/70">
                আমি যা বলবো হুবহু তাই পড়বে
              </span>
            </div>
          </div>

          {/* Mode Pill Toggle */}
          <div className="flex bg-black/40 rounded-xl p-0.5 border border-white/10 text-[10px] font-semibold">
            <button
              onClick={() => {
                onToggleMode('reader');
                playSound('pop');
              }}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                currentMode === 'reader'
                  ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              রিডার মোড
            </button>
            <button
              onClick={() => {
                onToggleMode('assistant');
                playSound('pop');
              }}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                currentMode === 'assistant'
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              স্মার্ট এআই
            </button>
          </div>
        </div>

        {/* Text Area */}
        <div className="relative">
          <textarea
            value={customText}
            onChange={(e) => setCustomText(e.target.value)}
            rows={3}
            placeholder="এখানে যেকোনো বাংলা বা ইংরেজি লেখা লিখুন বা মুখে বলুন, রাফি এআই পড়ে শোনাবে..."
            className="w-full bg-black/40 border border-purple-500/20 rounded-2xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-pink-400 resize-none font-medium leading-relaxed"
          />
          <div className="flex items-center justify-between text-[10px] text-purple-300/60 px-1 pt-1">
            <span>{customText.length} অক্ষর • {customText.trim() ? customText.trim().split(/\s+/).length : 0} শব্দ</span>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="hover:text-white flex items-center gap-0.5"
                title="Copy text"
              >
                {copied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                {copied ? 'কপি হয়েছে' : 'কপি'}
              </button>
              <button
                onClick={handleClear}
                className="hover:text-red-400 flex items-center gap-0.5"
                title="Clear text"
              >
                <RotateCcw className="w-3 h-3" />
                মুছুন
              </button>
            </div>
          </div>
        </div>

        {/* Big Action: Read Aloud */}
        <button
          onClick={handleSpeak}
          disabled={!customText.trim()}
          className={`w-full py-2.5 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-lg active:scale-98 disabled:opacity-40 ${
            voiceState === 'speaking'
              ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white animate-pulse shadow-pink-600/40'
              : 'bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 text-white shadow-purple-600/40 hover:opacity-95'
          }`}
        >
          <Volume2 className="w-4 h-4" />
          <span>{voiceState === 'speaking' ? 'রাফি এআই এখন পড়ছে...' : 'পড়ে শোনাও (Read Aloud)'}</span>
        </button>

        {/* Quick Click Presets */}
        <div className="space-y-1.5 pt-1">
          <span className="text-[10px] font-semibold text-purple-300/80 block">
            দ্রুত পড়ার নমুনা বাক্যসমূহ (ট্যাপ করলেই পড়বে):
          </span>
          <div className="flex flex-wrap gap-1.5">
            {PRESET_PHRASES.map((phrase, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setCustomText(phrase);
                  playSound('pop');
                  onSpeakText(phrase);
                }}
                className="text-[10px] px-2.5 py-1 rounded-xl bg-white/[0.05] hover:bg-white/10 border border-purple-500/20 text-purple-200 truncate max-w-full text-left active:scale-95 transition-all"
              >
                "{phrase.slice(0, 32)}..."
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
