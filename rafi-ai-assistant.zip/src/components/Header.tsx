import React, { useState, useEffect } from 'react';
import { MessageSquare, Settings as SettingsIcon, Video } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

interface HeaderProps {
  bossName: string;
  onOpenChat: () => void;
  onOpenSettings: () => void;
  onOpenVideoRef: () => void;
  unreadCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  bossName,
  onOpenChat,
  onOpenSettings,
  onOpenVideoRef,
  unreadCount = 0,
}) => {
  const [timeStr, setTimeStr] = useState<string>('11:58');
  const [dateStr, setDateStr] = useState<string>('Sun, 25 Oct');
  const [greeting, setGreeting] = useState<string>('Good morning');
  const [ghostWink, setGhostWink] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setTimeStr(`${hours}:${minutes}`);

      // Greeting
      const hr = now.getHours();
      if (hr < 12) setGreeting('Good morning');
      else if (hr < 17) setGreeting('Good afternoon');
      else setGreeting('Good evening');

      // Date format
      const options: Intl.DateTimeFormatOptions = { weekday: 'short', day: 'numeric', month: 'short' };
      setDateStr(now.toLocaleDateString('en-US', options));
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleGhostClick = () => {
    setGhostWink(true);
    playSound('ghost');
    setTimeout(() => setGhostWink(false), 1200);
  };

  return (
    <header className="w-full max-w-md mx-auto pt-3 pb-2 px-4 flex items-center justify-between select-none relative z-20">
      {/* Left: Chat thread toggle */}
      <div className="flex items-center gap-1.5">
        <button
          onClick={onOpenChat}
          className="relative w-10 h-10 rounded-2xl glass-panel flex items-center justify-center text-purple-200 hover:text-white hover:bg-white/10 active:scale-95 transition-all shadow-sm"
          title="Open Conversation History"
          aria-label="Open Conversation History"
        >
          <MessageSquare className="w-5 h-5" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-pink-500 text-[10px] font-bold text-white rounded-full flex items-center justify-center animate-pulse">
              {unreadCount}
            </span>
          )}
        </button>

        {/* Video reference button */}
        <button
          onClick={onOpenVideoRef}
          className="w-10 h-10 rounded-2xl glass-panel flex items-center justify-center text-cyan-300 hover:text-cyan-100 hover:bg-white/10 active:scale-95 transition-all text-xs"
          title="Watch Original Reference Video"
          aria-label="Watch Original Reference Video"
        >
          <Video className="w-4 h-4" />
        </button>
      </div>

      {/* Center: Brand & Time Header */}
      <div className="text-center flex-1 px-2">
        <div className="flex items-center justify-center gap-1.5">
          <h1 className="text-lg sm:text-xl font-extrabold tracking-tight bg-gradient-to-r from-purple-300 via-pink-300 to-cyan-300 bg-clip-text text-transparent">
            Rafi Ai Assistant
          </h1>
        </div>
        <p className="text-[11px] font-medium text-purple-200/70 tracking-wide mt-0.5">
          {greeting}, {bossName}
        </p>
        <div className="text-3xl font-extrabold tracking-tight text-white mt-1 font-mono flex items-center justify-center">
          <span>{timeStr.split(':')[0]}</span>
          <span className="animate-pulse text-purple-400 mx-0.5">:</span>
          <span>{timeStr.split(':')[1]}</span>
        </div>
        <p className="text-[11px] font-semibold text-purple-300/80 tracking-wider uppercase mt-0.5">
          {dateStr}
        </p>
      </div>

      {/* Right: Settings & Mascot Badge */}
      <div className="flex items-center gap-1.5">
        <button
          onClick={onOpenSettings}
          className="w-10 h-10 rounded-2xl glass-panel flex items-center justify-center text-purple-200 hover:text-white hover:bg-white/10 active:scale-95 transition-all shadow-sm"
          title="Settings"
          aria-label="Settings"
        >
          <SettingsIcon className="w-5 h-5" />
        </button>

        {/* Ghost mascot icon matching video */}
        <button
          onClick={handleGhostClick}
          className={`w-10 h-10 rounded-2xl glass-panel flex items-center justify-center active:scale-90 transition-transform ${
            ghostWink ? 'scale-125 rotate-12 ring-2 ring-pink-400 shadow-lg shadow-pink-500/30' : 'animate-float'
          }`}
          title="Tap Nūsu Ghost Mascot"
          aria-label="Nūsu Ghost Mascot"
        >
          <span className="text-xl select-none" role="img" aria-label="Nūsu ghost">
            {ghostWink ? '✨' : '👻'}
          </span>
        </button>
      </div>
    </header>
  );
};
