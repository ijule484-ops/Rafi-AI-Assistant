import React from 'react';
import { X, Play, Video as VideoIcon, ExternalLink, Sparkles } from 'lucide-react';

interface ReferenceVideoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReferenceVideoModal: React.FC<ReferenceVideoModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md rounded-3xl bg-[#0d0e19] border border-cyan-500/30 flex flex-col shadow-2xl overflow-hidden max-h-[92vh]">
        {/* Header */}
        <div className="p-3.5 border-b border-cyan-500/20 flex items-center justify-between bg-cyan-950/20">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-600/30 border border-cyan-400/30 flex items-center justify-center text-cyan-300">
              <VideoIcon className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xs font-bold text-white flex items-center gap-1.5">
                Original Demo Video
                <Sparkles className="w-3 h-3 text-cyan-400" />
              </h2>
              <p className="text-[10px] text-cyan-300/70">
                Nūsu AI Smart Voice Companion Reference
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-white/5 rounded-xl transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Player */}
        <div className="p-3 flex-1 flex flex-col items-center justify-center bg-black">
          <div className="relative w-full rounded-2xl overflow-hidden bg-black border border-white/10 shadow-lg">
            <video
              src="/assets/aistudio/VID_20261104_125316_236_799f2156.mp4"
              controls
              autoPlay
              playsInline
              className="w-full max-h-[55vh] object-contain mx-auto"
            />
          </div>

          <div className="mt-3 p-3 rounded-2xl glass-panel border border-purple-500/20 w-full text-xs text-slate-300 space-y-1">
            <div className="font-bold text-purple-300 flex items-center gap-1.5">
              <span>💡 ভিডিওর মূল ফিচারসমূহ:</span>
            </div>
            <ul className="list-disc list-inside text-[11px] text-purple-200/80 space-y-0.5">
              <li>নুসু এআই-কে বাংলায় কমান্ড দিলে ডিভাইস ও অ্যাপস নিয়ন্ত্রণ করা</li>
              <li>টিকটক ওপেন করে ইনবক্সে গিয়ে সাব্বিরের মেসেজ পড়ে শোনানো</li>
              <li>স্বয়ংক্রিয়ভাবে রিপ্লাই লেখা ("অসংখ্য ধন্যবাদ ভাইয়া!")</li>
              <li>হোম স্ক্রিনে ফিরে আসা ও সার্বক্ষণিক অ্যাসিস্ট্যান্ট মোড</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
