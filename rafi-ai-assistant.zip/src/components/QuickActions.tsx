import React from 'react';
import { ScreenShare, Brain, Languages } from 'lucide-react';

interface QuickActionsProps {
  onOpenScreenShare: () => void;
  onOpenMemories: () => void;
  onToggleLanguage: () => void;
  currentLang: string;
}

export const QuickActions: React.FC<QuickActionsProps> = ({
  onOpenScreenShare,
  onOpenMemories,
  onToggleLanguage,
  currentLang,
}) => {
  return (
    <div className="w-full max-w-md mx-auto px-4 py-2 grid grid-cols-3 gap-2.5 select-none">
      {/* 1. Screen / Share screen */}
      <button
        onClick={onOpenScreenShare}
        className="glass-panel hover:bg-white/[0.08] active:scale-95 transition-all rounded-2xl p-2.5 flex flex-col items-center justify-center text-center gap-1 group border border-purple-500/15"
      >
        <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-300 flex items-center justify-center group-hover:scale-110 transition-transform">
          <ScreenShare className="w-4 h-4" />
        </div>
        <span className="text-xs font-semibold text-slate-100 mt-0.5">Screen</span>
        <span className="text-[10px] text-purple-300/60 leading-tight">Share screen</span>
      </button>

      {/* 2. Memories / Recall Core */}
      <button
        onClick={onOpenMemories}
        className="glass-panel hover:bg-white/[0.08] active:scale-95 transition-all rounded-2xl p-2.5 flex flex-col items-center justify-center text-center gap-1 group border border-purple-500/15"
      >
        <div className="w-8 h-8 rounded-xl bg-pink-500/20 text-pink-300 flex items-center justify-center group-hover:scale-110 transition-transform">
          <Brain className="w-4 h-4" />
        </div>
        <span className="text-xs font-semibold text-slate-100 mt-0.5">Memories</span>
        <span className="text-[10px] text-pink-300/60 leading-tight">Recall Core</span>
      </button>

      {/* 3. Language / Auto */}
      <button
        onClick={onToggleLanguage}
        className="glass-panel hover:bg-white/[0.08] active:scale-95 transition-all rounded-2xl p-2.5 flex flex-col items-center justify-center text-center gap-1 group border border-purple-500/15"
      >
        <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-300 flex items-center justify-center group-hover:scale-110 transition-transform">
          <Languages className="w-4 h-4" />
        </div>
        <span className="text-xs font-semibold text-slate-100 mt-0.5">Language</span>
        <span className="text-[10px] text-cyan-300/60 leading-tight">
          {currentLang === 'bn-BD' ? 'বাংলা' : currentLang === 'en-US' ? 'English' : 'Auto'}
        </span>
      </button>
    </div>
  );
};
