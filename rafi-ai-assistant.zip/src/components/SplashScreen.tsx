import React, { useEffect, useState } from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

interface SplashScreenProps {
  onDismiss: () => void;
  creatorName?: string;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onDismiss,
  creatorName = 'Sabbir',
}) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    playSound('action');
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onDismiss, 600);
          return 100;
        }
        return prev + 12;
      });
    }, 120);

    return () => clearInterval(interval);
  }, [onDismiss]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between p-6 bg-black text-white select-none animate-in fade-in duration-300">
      {/* Background ambient cosmic glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-purple-900/40 via-pink-900/10 to-black pointer-events-none" />

      {/* Top indicator */}
      <div className="pt-4 text-xs font-mono text-purple-400/80 tracking-widest uppercase">
        System Initializing
      </div>

      {/* Center Branding matching video */}
      <div className="flex flex-col items-center text-center relative z-10 space-y-4">
        {/* Glowing Ghost Mascot */}
        <div className="relative">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-purple-600 to-pink-500 p-0.5 shadow-2xl shadow-purple-600/50 animate-bounce">
            <div className="w-full h-full rounded-[22px] bg-black/60 backdrop-blur-md flex items-center justify-center text-4xl">
              👻
            </div>
          </div>
          <div className="absolute -inset-2 bg-gradient-to-tr from-cyan-400 to-pink-500 rounded-3xl blur-xl opacity-40 animate-pulse-glow" />
        </div>

        {/* Title */}
        <div className="space-y-1">
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight bg-gradient-to-r from-cyan-300 via-purple-300 to-pink-400 bg-clip-text text-transparent">
            Rafi Ai Assistant
          </h1>
          <p className="text-sm font-semibold tracking-wide text-purple-200/90">
            Voice Reader & Smart Companion
          </p>
        </div>

        {/* Progress bar */}
        <div className="w-48 h-1 bg-white/10 rounded-full overflow-hidden mt-6">
          <div
            className="h-full bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 transition-all duration-200"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Bottom Subtitle / Attribution */}
      <div className="pb-6 flex flex-col items-center gap-3 relative z-10">
        <div className="flex items-center gap-2 text-xs text-purple-300/80 font-medium">
          <Sparkles className="w-3.5 h-3.5 text-pink-400 animate-spin-slow" />
          <span>Made by {creatorName}</span>
        </div>

        <button
          onClick={onDismiss}
          className="text-xs text-slate-400 hover:text-white flex items-center gap-1 active:scale-95 transition-all"
        >
          Skip intro <ArrowRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
