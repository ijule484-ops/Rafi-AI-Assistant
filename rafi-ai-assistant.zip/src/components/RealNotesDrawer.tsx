import React, { useState } from 'react';
import { X, FileText, Plus, Trash2, Copy, Check, Volume2, Sparkles } from 'lucide-react';
import { RealNoteItem } from '../types';
import { playSound } from '../utils/soundEffects';

interface RealNotesDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  notes: RealNoteItem[];
  onAddNote: (content: string) => void;
  onDeleteNote: (id: string) => void;
  onSpeakNote: (content: string) => void;
  bossName: string;
}

export const RealNotesDrawer: React.FC<RealNotesDrawerProps> = ({
  isOpen,
  onClose,
  notes,
  onAddNote,
  onDeleteNote,
  onSpeakNote,
  bossName,
}) => {
  const [newNoteText, setNewNoteText] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteText.trim()) return;
    onAddNote(newNoteText.trim());
    setNewNoteText('');
    playSound('pop');
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    playSound('pop');
    setTimeout(() => setCopiedId(null), 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md rounded-3xl bg-[#110e19] border border-amber-500/30 flex flex-col shadow-2xl overflow-hidden max-h-[88vh]">
        {/* Header */}
        <div className="p-3.5 border-b border-amber-500/20 flex items-center justify-between bg-amber-950/20">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-600/20 border border-amber-400/30 flex items-center justify-center text-amber-300">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xs font-bold text-white flex items-center gap-1.5">
                Rafi AI Notes & Diary
                <Sparkles className="w-3 h-3 text-amber-400" />
              </h2>
              <p className="text-[10px] text-amber-300/70">
                {bossName} ভাইয়ের সেভ করা আসল নোটসমূহ
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-white/5 rounded-xl transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-3 overflow-y-auto flex-1">
          {/* Add Note Form */}
          <form onSubmit={handleAdd} className="flex gap-2">
            <input
              type="text"
              value={newNoteText}
              onChange={(e) => setNewNoteText(e.target.value)}
              placeholder="নতুন নোট লিখুন বা মুখে বলুন..."
              className="flex-1 bg-white/5 border border-amber-500/30 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
            />
            <button
              type="submit"
              disabled={!newNoteText.trim()}
              className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center gap-1 disabled:opacity-40 active:scale-95 transition-all shadow-md"
            >
              <Plus className="w-4 h-4" />
              সেভ
            </button>
          </form>

          {/* Notes list */}
          <div className="space-y-2 pt-1">
            {notes.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">
                কোনো নোট সেভ করা নেই। মুখে বলুন: "নোট লেখো: ..." অথবা উপরে লিখে সেভ করুন।
              </div>
            ) : (
              notes.map((item) => (
                <div
                  key={item.id}
                  className="p-3 rounded-2xl bg-white/[0.04] border border-amber-500/20 space-y-2 hover:bg-white/[0.07] transition-all"
                >
                  <p className="text-xs text-slate-100 leading-relaxed font-medium">
                    {item.content}
                  </p>
                  <div className="flex items-center justify-between text-[10px] text-amber-300/70 pt-1 border-t border-white/5">
                    <span>{item.timestamp}</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onSpeakNote(item.content)}
                        className="hover:text-white flex items-center gap-0.5"
                        title="Read note"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                        পড়ো
                      </button>
                      <button
                        onClick={() => handleCopy(item.id, item.content)}
                        className="hover:text-white flex items-center gap-0.5"
                        title="Copy note"
                      >
                        {copiedId === item.id ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                        {copiedId === item.id ? 'কপি হয়েছে' : 'কপি'}
                      </button>
                      <button
                        onClick={() => {
                          onDeleteNote(item.id);
                          playSound('pop');
                        }}
                        className="hover:text-red-400 text-slate-500"
                        title="Delete note"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
