import React, { useState, useRef, useEffect } from 'react';
import { X, Camera, RefreshCw, Sparkles, Check, Download } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

interface RealCameraModalProps {
  isOpen: boolean;
  onClose: () => void;
  bossName: string;
}

export const RealCameraModal: React.FC<RealCameraModalProps> = ({ isOpen, onClose, bossName }) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      return;
    }

    startCamera(facingMode);

    return () => {
      stopCamera();
    };
  }, [isOpen, facingMode]);

  const startCamera = async (mode: 'user' | 'environment') => {
    stopCamera();
    setErrorMsg('');
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: mode, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.play();
      }
    } catch (err: any) {
      console.warn('Camera permission or device error:', err);
      setErrorMsg('ক্যামেরা পারমিশন পাওয়া যায়নি। ব্রাউজারে ক্যামেরা পারমিশন এলাও করুন।');
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const handleCapture = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const photoUrl = canvas.toDataURL('image/jpeg', 0.9);
    setCapturedPhoto(photoUrl);
    playSound('action');
  };

  const toggleFacingMode = () => {
    setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
    playSound('pop');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md rounded-3xl bg-[#090a12] border border-cyan-500/30 flex flex-col shadow-2xl overflow-hidden max-h-[92vh]">
        {/* Header */}
        <div className="p-3.5 border-b border-cyan-500/20 flex items-center justify-between bg-cyan-950/20">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400/30 flex items-center justify-center text-cyan-300">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xs font-bold text-white flex items-center gap-1.5">
                Rafi AI Camera
                <Sparkles className="w-3 h-3 text-cyan-400" />
              </h2>
              <p className="text-[10px] text-cyan-300/70">
                {bossName} ভাইয়ের ফোনের লাইভ ক্যামেরা
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-white/5 rounded-xl transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewfinder or Captured Photo */}
        <div className="relative flex-1 bg-black min-h-[340px] flex items-center justify-center overflow-hidden">
          {capturedPhoto ? (
            <div className="relative w-full h-full flex flex-col items-center justify-center p-2">
              <img
                src={capturedPhoto}
                alt="Captured"
                className="max-h-[60vh] rounded-2xl object-contain border border-white/10"
              />
              <div className="absolute bottom-4 flex gap-3">
                <button
                  onClick={() => setCapturedPhoto(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-white text-xs font-bold active:scale-95 shadow-lg"
                >
                  আবার তোলো
                </button>
                <a
                  href={capturedPhoto}
                  download={`Rafi_AI_Photo_${Date.now()}.jpg`}
                  className="px-4 py-2 rounded-xl bg-cyan-600 text-white text-xs font-bold active:scale-95 shadow-lg flex items-center gap-1.5"
                >
                  <Download className="w-4 h-4" />
                  ডাউনলোড করুন
                </a>
              </div>
            </div>
          ) : (
            <>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover min-h-[340px]"
              />

              {errorMsg && (
                <div className="absolute inset-0 p-6 flex flex-col items-center justify-center text-center bg-black/80 text-amber-200 text-xs">
                  <Camera className="w-10 h-10 text-amber-400 mb-2 opacity-50" />
                  <p>{errorMsg}</p>
                </div>
              )}
            </>
          )}
        </div>

        {/* Controls */}
        {!capturedPhoto && (
          <div className="p-4 bg-zinc-950 flex items-center justify-around border-t border-white/10">
            <button
              onClick={toggleFacingMode}
              className="w-11 h-11 rounded-2xl bg-slate-900 border border-slate-700 flex items-center justify-center text-slate-300 active:scale-90 transition-transform"
              title="Flip camera"
            >
              <RefreshCw className="w-5 h-5" />
            </button>

            {/* Shutter Button */}
            <button
              onClick={handleCapture}
              className="w-16 h-16 rounded-full border-4 border-white bg-white/20 hover:bg-white/40 active:scale-90 transition-transform flex items-center justify-center shadow-xl shadow-cyan-500/20"
              title="Capture Photo"
            >
              <div className="w-12 h-12 rounded-full bg-white shadow-md" />
            </button>

            <button
              onClick={onClose}
              className="w-11 h-11 rounded-2xl bg-slate-900 border border-slate-700 flex items-center justify-center text-slate-300 active:scale-90 transition-transform"
            >
              <Check className="w-5 h-5 text-green-400" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
