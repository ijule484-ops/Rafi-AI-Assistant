import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  Mic,
  Home as HomeIcon,
  MessageSquare,
  Sparkles,
  BookOpen,
  Send,
  AlertCircle,
  LayoutGrid,
} from 'lucide-react';

import {
  VoiceState,
  AppTab,
  InteractionMode,
  MessageItem,
  WeatherData,
  MemoryItem,
  NusuSettings,
  RealNoteItem,
  ActionExecution,
} from './types';

import { playSound } from './utils/soundEffects';
import { speechEngine } from './utils/speechEngine';
import { parseUserCommand } from './utils/actionParser';

import { SplashScreen } from './components/SplashScreen';
import { Header } from './components/Header';
import { GlowingOrb } from './components/GlowingOrb';
import { WeatherCard } from './components/WeatherCard';
import { QuickActions } from './components/QuickActions';
import { VoiceReaderPanel } from './components/VoiceReaderPanel';
import { AppsHub } from './components/AppsHub';
import { ActionBanner } from './components/ActionBanner';
import { FloatingGhostWidget } from './components/FloatingGhostWidget';
import { RealCameraModal } from './components/RealCameraModal';
import { RealMusicPlayerModal } from './components/RealMusicPlayerModal';
import { RealNotesDrawer } from './components/RealNotesDrawer';
import { ChatDrawer } from './components/ChatDrawer';
import { MemoriesModal } from './components/MemoriesModal';
import { ScreenShareModal } from './components/ScreenShareModal';
import { SettingsModal } from './components/SettingsModal';
import { ReferenceVideoModal } from './components/ReferenceVideoModal';

const DEFAULT_MEMORIES: MemoryItem[] = [
  { id: '1', key: 'বস (Boss)', value: 'রাফি (Rafi Boss)', category: 'personal' },
  { id: '2', key: 'অ্যাসিস্ট্যান্ট (Assistant)', value: 'Rafi Ai Assistant - আপনার ফোনের আসল সাথী', category: 'system' },
  { id: '3', key: 'ক্ষমতা (Capability)', value: 'কথা শোনার পাশাপাশি ফোনে আসল কাজগুলো সম্পন্ন করা', category: 'preference' },
  { id: '4', key: 'প্রিয় কাজ (Favorite Actions)', value: 'ইউটিউব, গান বাজানো, ক্যামেরা, হোয়াটসঅ্যাপ ও কল', category: 'preference' },
];

const INITIAL_NOTES: RealNoteItem[] = [
  { id: '1', content: 'রাফি এআই অ্যাসিস্ট্যান্ট প্রজেক্ট সফলভাবে প্রস্তুত হয়েছে', timestamp: 'আজ ১২:০০ PM' },
  { id: '2', content: 'ভিডিও বানিয়ে সাব্বির ভাইকে মেনশন দিয়ে পোস্ট করতে হবে', timestamp: 'গতকাল ১০:১৫ PM' },
];

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [activeTab, setActiveTab] = useState<AppTab>('home');
  const [voiceState, setVoiceState] = useState<VoiceState>('idle');

  // Mode: 'assistant' (performs actions & speaks) vs 'reader' ("আমি যা বলব তাই পড়বে সে")
  const [currentMode, setCurrentMode] = useState<InteractionMode>('assistant');

  // Transcripts & Dialog
  const [transcript, setTranscript] = useState<string>('');
  const [nusuSpokenText, setNusuSpokenText] = useState<string>(
    'হ্যালো রাফি বস! আমি রাফি এআই অ্যাসিস্ট্যান্ট। আপনি যা বলবেন আমি উত্তর দেওয়ার পাশাপাশি আপনার ফোনের কাজও করে দেবো।'
  );

  // Active executed action banner
  const [activeAction, setActiveAction] = useState<ActionExecution | null>(null);

  // Real Persistent Notes in localStorage
  const [notes, setNotes] = useState<RealNoteItem[]>(() => {
    try {
      const saved = localStorage.getItem('rafi_ai_notes');
      return saved ? JSON.parse(saved) : INITIAL_NOTES;
    } catch {
      return INITIAL_NOTES;
    }
  });

  // Action Modals
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [isMusicOpen, setIsMusicOpen] = useState(false);
  const [isNotesOpen, setIsNotesOpen] = useState(false);

  // Mic Notice / Error feedback
  const [micNotice, setMicNotice] = useState<string | null>(null);

  // Text Command input
  const [commandInputText, setCommandInputText] = useState('');

  // Messages log
  const [messages, setMessages] = useState<MessageItem[]>([
    {
      id: 'init-1',
      sender: 'nusu',
      text: 'হ্যালো রাফি বস! আমি রাফি এআই অ্যাসিস্ট্যান্ট। আপনি যা বলবেন আমি কথা বলার পাশাপাশি ফোনে সরাসরি সেই কাজও করে দেবো।',
      timestamp: '11:58 AM',
      mode: 'assistant',
    },
  ]);

  // Weather
  const [weather] = useState<WeatherData>({
    temp: 31,
    condition: 'Clear Sky',
    city: 'Madhabpur',
    feelsLike: 37,
    high: 32,
    low: 23,
    humidity: 64,
  });

  // Memories
  const [memories, setMemories] = useState<MemoryItem[]>(DEFAULT_MEMORIES);

  // Settings
  const [settings, setSettings] = useState<NusuSettings>({
    bossName: 'রাফি',
    creatorName: 'Rafi & Sabbir',
    language: 'auto',
    voiceSpeed: 1.0,
    voicePitch: 1.15,
    autoSpeak: true,
    hapticFeedback: true,
    defaultMode: 'assistant',
  });

  // Dialog Modals
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isMemoriesOpen, setIsMemoriesOpen] = useState(false);
  const [isScreenShareOpen, setIsScreenShareOpen] = useState(false);
  const [isVideoRefOpen, setIsVideoRefOpen] = useState(false);
  const [isAnalyzingScreen, setIsAnalyzingScreen] = useState(false);

  // Save notes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('rafi_ai_notes', JSON.stringify(notes));
    } catch {}
  }, [notes]);

  // Initial welcome voice once splash screen finishes
  useEffect(() => {
    if (!showSplash && settings.autoSpeak) {
      setTimeout(() => {
        speakNusuReply('হ্যালো রাফি বস! আমি রাফি এআই অ্যাসিস্ট্যান্ট। আপনি যা বলবেন আমি তা করার পাশাপাশি সুন্দরভাবে পড়ে শোনাবো।');
      }, 700);
    }
  }, [showSplash]);

  // Speak helper using speechEngine
  const speakNusuReply = (text: string) => {
    setNusuSpokenText(text);
    if (!settings.autoSpeak) return;

    speechEngine.speak(text, {
      speed: settings.voiceSpeed,
      pitch: settings.voicePitch,
      lang: settings.language === 'en-US' ? 'en-US' : 'bn-BD',
      onStart: () => {
        setVoiceState('speaking');
      },
      onEnd: () => {
        setVoiceState('idle');
      },
      onError: () => {
        setVoiceState('idle');
      },
    });
  };

  // Toggle Microphone
  const handleToggleMic = () => {
    if (voiceState === 'speaking') {
      speechEngine.stopSpeaking();
      setVoiceState('idle');
      return;
    }

    if (voiceState === 'listening') {
      speechEngine.stopListening();
      setVoiceState('idle');
      playSound('mic_off');
      return;
    }

    playSound('mic_on');
    setVoiceState('listening');
    setTranscript('');
    setMicNotice(null);

    const targetLang = settings.language === 'en-US' ? 'en-US' : 'bn-BD';

    const success = speechEngine.startListening(
      (text, isFinal) => {
        setTranscript(text);
        if (isFinal && text.trim().length > 0) {
          handleUserVoicePrompt(text.trim());
        }
      },
      (error) => {
        console.warn('Speech recognition notice:', error);
        setMicNotice(error);
        setVoiceState('idle');
      },
      () => {
        setVoiceState((prev) => (prev === 'listening' ? 'idle' : prev));
      },
      targetLang
    );

    if (!success) {
      setVoiceState('idle');
      setMicNotice('মাইক্রোফোন পারমিশন অন করুন, অথবা নিচের বক্সে লিখে যেকোনো নির্দেশ দিন।');
    }
  };

  // Process voice/text prompt
  const handleUserVoicePrompt = async (promptText: string) => {
    speechEngine.stopListening();
    setVoiceState('processing');
    setTranscript(promptText);
    setMicNotice(null);

    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    // Add user message to history
    const userMsg: MessageItem = {
      id: Date.now().toString(),
      sender: 'user',
      text: promptText,
      timestamp: timeStr,
      mode: currentMode,
    };
    setMessages((prev) => [...prev, userMsg]);

    const lower = promptText.toLowerCase().trim();

    // Mode switching voice commands
    if (lower.includes('রিডার মোড') || lower.includes('reader mode') || lower.includes('পড়ার মোড')) {
      setCurrentMode('reader');
      const reply = `হ্যাঁ ${settings.bossName} ভাই, ভয়েস রিডার মোড চালু হয়েছে। এখন আপনি যা বলবেন আমি হুবহু তাই পড়ে শোনাবো।`;
      addNusuReply(reply, 'SWITCH_MODE:reader');
      speakNusuReply(reply);
      return;
    }

    if (lower.includes('স্মার্ট মোড') || lower.includes('assistant mode') || lower.includes('সহকারী মোড')) {
      setCurrentMode('assistant');
      const reply = `হ্যাঁ ${settings.bossName} ভাই, স্মার্ট সহকারী মোড চালু হয়েছে। আমি কথা বলার পাশাপাশি আপনার ফোনের কাজও সম্পন্ন করবো।`;
      addNusuReply(reply, 'SWITCH_MODE:assistant');
      speakNusuReply(reply);
      return;
    }

    // 1. UNIVERSAL ACTION PARSER (Performs the real action on the phone + speaks)
    const parsed = parseUserCommand(promptText, settings.bossName);

    if (parsed.handled) {
      // Execute the real action!
      if (parsed.execution) {
        setActiveAction(parsed.execution);
        executeRealAction(parsed.execution);
      }

      if (parsed.noteText) {
        handleAddNote(parsed.noteText);
      }

      if (parsed.actionTag?.includes('SEND_MESSAGE') || parsed.actionTag?.includes('dhonnobad')) {
        confetti({ particleCount: 35, spread: 65, origin: { y: 0.7 } });
      }

      addNusuReply(parsed.speechReply, parsed.actionTag || 'ACTION');
      speakNusuReply(parsed.speechReply);
      return;
    }

    // 2. READER MODE: "আমি যা বলবো তাই পড়বে সে"
    if (currentMode === 'reader') {
      addNusuReply(promptText, 'VOICE_READER');
      speakNusuReply(promptText);
      return;
    }

    // 3. SMART ASSISTANT: Ask Server Gemini 3.8 Flash
    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: promptText,
          history: messages.slice(-6),
          bossName: settings.bossName,
        }),
      });

      const data = await response.json();
      const reply = data.speechText || `হ্যাঁ ${settings.bossName} ভাই, আমি আপনার নির্দেশ বুঝতে পেরেছি।`;

      if (data.action) {
        const actionParsed = parseUserCommand(data.action, settings.bossName);
        if (actionParsed.execution) {
          setActiveAction(actionParsed.execution);
          executeRealAction(actionParsed.execution);
        }
      }

      addNusuReply(reply, data.action);
      speakNusuReply(reply);
    } catch (err: any) {
      console.warn('Backend fallback:', err);
      const fallback = `হ্যাঁ ${settings.bossName} ভাই, আমি আপনার কথা শুনতে পেয়েছি: "${promptText}"। আর কি কাজ করতে হবে বলুন?`;
      addNusuReply(fallback);
      speakNusuReply(fallback);
    }
  };

  // Real device & web action executor (actually DOES the work)
  const executeRealAction = (action: ActionExecution) => {
    playSound('action');

    switch (action.type) {
      case 'open_youtube': {
        // Open YouTube link or app
        if (action.url) {
          window.open(action.url, '_blank', 'noopener,noreferrer');
        }
        break;
      }
      case 'open_tiktok': {
        if (action.url) {
          window.open(action.url, '_blank', 'noopener,noreferrer');
        }
        break;
      }
      case 'open_whatsapp': {
        if (action.url) {
          window.open(action.url, '_blank', 'noopener,noreferrer');
        }
        break;
      }
      case 'make_call': {
        // Actual phone call dialer
        if (action.url) {
          window.location.href = action.url;
        }
        break;
      }
      case 'open_camera': {
        // Real camera viewfinder
        setIsCameraOpen(true);
        break;
      }
      case 'play_music': {
        // Real music player
        setIsMusicOpen(true);
        break;
      }
      case 'save_note': {
        setIsNotesOpen(true);
        break;
      }
      case 'open_google': {
        if (action.url) {
          window.open(action.url, '_blank', 'noopener,noreferrer');
        }
        break;
      }
      case 'show_weather': {
        // Weather card is already live
        break;
      }
    }
  };

  // Add real note
  const handleAddNote = (content: string) => {
    const newNote: RealNoteItem = {
      id: Date.now().toString(),
      content,
      timestamp: 'এখন ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setNotes((prev) => [newNote, ...prev]);
  };

  // Delete note
  const handleDeleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
  };

  const addNusuReply = (text: string, actionTaken?: string) => {
    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    setMessages((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        sender: 'nusu',
        text,
        timestamp: timeStr,
        actionTaken,
        mode: currentMode,
      },
    ]);
  };

  // Screen Analysis with Gemini Multimodal
  const handleAnalyzeScreen = async (imageBase64: string, question?: string) => {
    setIsAnalyzingScreen(true);
    setVoiceState('processing');
    try {
      const res = await fetch('/api/analyze-screen', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64,
          question: question || 'এই স্ক্রিনে কি দেখতে পাচ্ছো বসকে বাংলায় বলো',
        }),
      });
      const data = await res.json();
      const reply = data.speechText || `${settings.bossName}, আমি স্ক্রিনের কন্টেন্ট দেখতে পেয়েছি।`;
      addNusuReply(reply, 'SCREEN_INSPECT');
      speakNusuReply(reply);
      setIsScreenShareOpen(false);
    } catch {
      const fallback = `${settings.bossName}, স্ক্রিন বিশ্লেষণ করা হয়েছে।`;
      addNusuReply(fallback, 'SCREEN_INSPECT');
      speakNusuReply(fallback);
    } finally {
      setIsAnalyzingScreen(false);
    }
  };

  // Recall core memories
  const handleRecallMemories = () => {
    const memorySpeech = `${settings.bossName} ভাই, আমি মনে রেখেছি: আপনি যা বলবেন আমি সাথে সাথে তার উত্তর দেওয়ার পাশাপাশি আপনার ফোনের কাজও সম্পন্ন করে দেবো!`;
    addNusuReply(memorySpeech, 'RECALL_CORE');
    speakNusuReply(memorySpeech);
    setIsMemoriesOpen(false);
  };

  // Test Voice in settings
  const handleTestVoice = () => {
    speakNusuReply(`হ্যালো ${settings.bossName} ভাই! আমি আপনার রাফি এআই অ্যাসিস্ট্যান্ট। আপনি যা বলবেন আমি উত্তর দেওয়ার পাশাপাশি সব কাজও করে দেবো।`);
  };

  // Language toggle shortcut
  const handleToggleLanguage = () => {
    setSettings((prev) => {
      const nextLang = prev.language === 'auto' ? 'bn-BD' : prev.language === 'bn-BD' ? 'en-US' : 'auto';
      playSound('pop');
      return { ...prev, language: nextLang };
    });
  };

  const handleCommandFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commandInputText.trim()) return;
    handleUserVoicePrompt(commandInputText.trim());
    setCommandInputText('');
  };

  if (showSplash) {
    return (
      <SplashScreen
        onDismiss={() => setShowSplash(false)}
        creatorName={settings.creatorName}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#090a12] text-slate-100 flex flex-col justify-between selection:bg-purple-500/30 font-sans relative overflow-x-hidden">
      
      {/* Background soft ambient gradient illumination */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-96 h-96 bg-purple-600/15 rounded-full blur-[120px]" />
        <div className="absolute top-1/3 -left-32 w-80 h-80 bg-pink-600/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-10 -right-32 w-80 h-80 bg-cyan-600/10 rounded-full blur-[120px]" />
      </div>

      {/* Main Container tailored for real smartphone screens */}
      <div className="relative z-10 w-full max-w-md mx-auto flex-1 flex flex-col justify-between pb-24">
        
        {/* Top Header */}
        <Header
          bossName={settings.bossName}
          onOpenChat={() => setIsChatOpen(true)}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenVideoRef={() => setIsVideoRefOpen(true)}
          unreadCount={messages.filter((m) => m.sender === 'nusu').length}
        />

        {/* Live Action Execution Banner */}
        <ActionBanner
          action={activeAction}
          onDismiss={() => setActiveAction(null)}
        />

        {/* TAB 1: MAIN COMPANION SCREEN (Home) */}
        {activeTab === 'home' && (
          <main className="flex-1 flex flex-col items-center justify-around px-4 py-1 select-none">
            
            {/* Mode Switcher */}
            <div className="w-full max-w-md flex items-center justify-between px-2 pt-1 pb-1">
              <div className="flex items-center gap-1.5 text-xs">
                <span className="w-2 h-2 rounded-full bg-pink-400 animate-pulse" />
                <span className="text-purple-200 font-semibold">
                  {currentMode === 'assistant' ? 'স্মার্ট সহকারী (উত্তর + কাজ)' : 'ভয়েস রিডার মোড'}
                </span>
              </div>

              <div className="flex bg-black/40 rounded-xl p-0.5 border border-purple-500/20 text-[10px]">
                <button
                  onClick={() => {
                    setCurrentMode('assistant');
                    playSound('pop');
                  }}
                  className={`px-2.5 py-1 rounded-lg font-semibold transition-all ${
                    currentMode === 'assistant'
                      ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  উত্তর + কাজ
                </button>
                <button
                  onClick={() => {
                    setCurrentMode('reader');
                    playSound('pop');
                  }}
                  className={`px-2.5 py-1 rounded-lg font-semibold transition-all ${
                    currentMode === 'reader'
                      ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  শুধু পড়বে
                </button>
              </div>
            </div>

            {/* Mic Notice Banner */}
            {micNotice && (
              <div className="w-full max-w-md mx-auto px-2 py-1">
                <div className="p-2 rounded-xl bg-amber-950/50 border border-amber-500/30 flex items-center gap-2 text-[11px] text-amber-200 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span className="flex-1">{micNotice}</span>
                  <button onClick={() => setMicNotice(null)} className="text-amber-400 hover:text-white font-bold px-1">
                    ✕
                  </button>
                </div>
              </div>
            )}

            {/* Center Hypnotic Holographic Voice Orb */}
            <div className="flex flex-col items-center justify-center my-1 relative">
              <GlowingOrb
                state={voiceState}
                onClick={handleToggleMic}
                size={250}
              />

              {/* Status Badge below Orb */}
              <div className="mt-2.5 flex flex-col items-center gap-1">
                <button
                  onClick={handleToggleMic}
                  className={`px-4 py-1.5 rounded-full text-xs font-bold tracking-wide transition-all shadow-md active:scale-95 flex items-center gap-2 border ${
                    voiceState === 'speaking'
                      ? 'bg-pink-600/30 border-pink-400/50 text-pink-200 animate-pulse'
                      : voiceState === 'listening'
                      ? 'bg-cyan-600/30 border-cyan-400/50 text-cyan-200 animate-pulse'
                      : voiceState === 'processing'
                      ? 'bg-amber-600/30 border-amber-400/50 text-amber-200'
                      : 'bg-purple-900/30 border-purple-500/40 text-purple-200 hover:bg-purple-800/40'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      voiceState === 'speaking'
                        ? 'bg-pink-400 animate-ping'
                        : voiceState === 'listening'
                        ? 'bg-cyan-400 animate-ping'
                        : voiceState === 'processing'
                        ? 'bg-amber-400'
                        : 'bg-purple-400'
                    }`}
                  />
                  <span>
                    {voiceState === 'speaking' && '• RAFI AI IS SPEAKING...'}
                    {voiceState === 'listening' && '• MIC ON - LISTENING...'}
                    {voiceState === 'processing' && '• EXECUTING COMMAND...'}
                    {voiceState === 'idle' && (currentMode === 'reader' ? '• READY TO READ' : '• MIC ON - READY')}
                  </span>
                </button>

                <p className="text-[10px] text-purple-300/60 font-medium tracking-wide">
                  {voiceState === 'speaking'
                    ? 'Tap mic to interrupt'
                    : voiceState === 'listening'
                    ? 'কথা বলুন • রাফি এআই উত্তর দিয়ে কাজ করবে'
                    : 'মাইকে কথা বলুন বা নিচের বক্সে লিখে কমান্ড দিন'}
                </p>
              </div>

              {/* Live Speech Transcript Bubble */}
              {transcript && (
                <div className="mt-2 px-4 py-1.5 rounded-2xl bg-purple-950/70 border border-purple-500/30 backdrop-blur-md shadow-xl text-center max-w-[92%] animate-in fade-in slide-in-from-bottom-2">
                  <div className="text-[10px] text-pink-400 font-bold uppercase tracking-wider mb-0.5">
                    🗣️ আপনার বলা কথা
                  </div>
                  <p className="text-xs text-white font-medium italic">
                    "{transcript}"
                  </p>
                </div>
              )}

              {/* Rafi AI Spoken Response Bubble */}
              {nusuSpokenText && !transcript && (
                <div className="mt-2 px-4 py-1.5 rounded-2xl bg-white/[0.06] border border-purple-400/20 backdrop-blur-md text-center max-w-[92%] animate-in fade-in">
                  <div className="text-[10px] text-cyan-300 font-bold uppercase tracking-wider mb-0.5 flex items-center justify-center gap-1">
                    <span>👻 Rafi Ai Assistant</span>
                    <Sparkles className="w-3 h-3 text-pink-400" />
                  </div>
                  <p className="text-xs text-purple-100 font-medium leading-relaxed">
                    "{nusuSpokenText}"
                  </p>
                </div>
              )}
            </div>

            {/* Permanent Command Input Box */}
            <form
              onSubmit={handleCommandFormSubmit}
              className="w-full max-w-md mx-auto px-4 py-1"
            >
              <div className="glass-panel rounded-2xl p-1.5 flex items-center gap-2 border border-purple-500/30 shadow-md">
                <input
                  type="text"
                  value={commandInputText}
                  onChange={(e) => setCommandInputText(e.target.value)}
                  placeholder="যেকোনো কমান্ড লিখুন (যেমন: ইউটিউব খোলো, গান বাজাও, কৌতুক বলো)..."
                  className="flex-1 bg-transparent px-3 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={!commandInputText.trim()}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 text-white text-[11px] font-bold shadow-md active:scale-95 disabled:opacity-40 flex items-center gap-1 transition-all"
                >
                  <Send className="w-3 h-3" />
                  করো
                </button>
              </div>
            </form>

            {/* Quick 1-Tap Real Action Chips */}
            <div className="w-full max-w-md mx-auto px-4 py-1">
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
                {[
                  { label: '📺 ইউটিউব খোলো', cmd: 'ইউটিউব খোলো' },
                  { label: '🎵 গান বাজাও', cmd: 'গান বাজাও' },
                  { label: '📸 ক্যামেরা অন করো', cmd: 'ক্যামেরা অন করো' },
                  { label: '📞 সাব্বিরকে কল দাও', cmd: 'সাব্বিরকে কল দাও' },
                  { label: '💬 হোয়াটসঅ্যাপ খোলো', cmd: 'হোয়াটসঅ্যাপ খোলো' },
                  { label: '📱 টিকটক ওপেন করো', cmd: 'টিকটক ওপেন করো' },
                  { label: '📝 নোট লেখো', cmd: 'নোট লেখো: আগামীকাল মিটিং আছে' },
                  { label: '🔢 হিসাব করো', cmd: '৫০ গুণন ১০ কত?' },
                  { label: '😂 কৌতুক বলো', cmd: 'একটা মজার কৌতুক বলো' },
                  { label: '📖 গল্প বলো', cmd: 'একটি শিক্ষণীয় গল্প বলো' },
                  { label: '🌤️ আবহাওয়া কেমন', cmd: 'আজকের আবহাওয়া কেমন?' },
                ].map((chip, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleUserVoicePrompt(chip.cmd)}
                    className="text-[10px] whitespace-nowrap px-2.5 py-1 rounded-full bg-purple-950/40 hover:bg-purple-800/50 border border-purple-500/25 text-purple-200 active:scale-95 transition-all shadow-sm"
                  >
                    {chip.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Weather Widget Card matching Madhabpur */}
            <WeatherCard
              weather={weather}
              onAskWeather={() => handleUserVoicePrompt('আজকের আবহাওয়া কেমন?')}
            />

            {/* Quick Action 3-card bar */}
            <QuickActions
              onOpenScreenShare={() => setIsScreenShareOpen(true)}
              onOpenMemories={() => setIsMemoriesOpen(true)}
              onToggleLanguage={handleToggleLanguage}
              currentLang={settings.language}
            />
          </main>
        )}

        {/* TAB 2: DEDICATED VOICE READER PANEL ("আমি যা বলব তাই পড়বে সে") */}
        {activeTab === 'reader' && (
          <main className="flex-1 flex flex-col justify-center py-2">
            <VoiceReaderPanel
              onSpeakText={(text) => {
                addNusuReply(text, 'VOICE_READER');
                speakNusuReply(text);
              }}
              voiceState={voiceState}
              currentMode={currentMode}
              onToggleMode={(mode) => setCurrentMode(mode)}
              bossName={settings.bossName}
            />
          </main>
        )}

        {/* TAB 3: REAL MOBILE APPS & ACTION HUB (Replaces fake phone simulator) */}
        {activeTab === 'tools' && (
          <main className="flex-1 flex flex-col justify-center py-2">
            <AppsHub
              onTriggerCommand={handleUserVoicePrompt}
              onOpenMusic={() => setIsMusicOpen(true)}
              onOpenCamera={() => setIsCameraOpen(true)}
              onOpenNotes={() => setIsNotesOpen(true)}
              bossName={settings.bossName}
            />
          </main>
        )}

      </div>

      {/* Floating Ghost Mascot Widget directly on user's real smartphone screen */}
      <FloatingGhostWidget
        voiceState={voiceState}
        onTap={handleToggleMic}
        spokenText={nusuSpokenText}
        bossName={settings.bossName}
      />

      {/* Real Smartphone Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0c0d16]/90 backdrop-blur-xl border-t border-purple-500/20 py-2 px-4 sm:px-6">
        <div className="max-w-md mx-auto flex items-center justify-between relative">
          
          {/* 1. Home tab */}
          <button
            onClick={() => {
              setActiveTab('home');
              playSound('pop');
            }}
            className={`flex flex-col items-center gap-1 transition-all ${
              activeTab === 'home'
                ? 'text-purple-300 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className={`p-1.5 rounded-xl ${activeTab === 'home' ? 'bg-purple-600/30' : ''}`}>
              <HomeIcon className="w-5 h-5" />
            </div>
            <span className="text-[10px]">Home</span>
          </button>

          {/* 2. Reader tab ("আমি যা বলবো তাই পড়বে") */}
          <button
            onClick={() => {
              setActiveTab('reader');
              playSound('pop');
            }}
            className={`flex flex-col items-center gap-1 transition-all ${
              activeTab === 'reader'
                ? 'text-pink-300 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className={`p-1.5 rounded-xl ${activeTab === 'reader' ? 'bg-pink-600/30' : ''}`}>
              <BookOpen className="w-5 h-5" />
            </div>
            <span className="text-[10px]">রিডার</span>
          </button>

          {/* 3. CENTER ELEVATED GLOWING MIC BUTTON */}
          <div className="relative -top-5">
            <button
              onClick={handleToggleMic}
              className={`w-14 h-14 rounded-full flex items-center justify-center text-white shadow-xl transition-all active:scale-90 ${
                voiceState === 'listening'
                  ? 'bg-gradient-to-tr from-cyan-400 to-blue-600 ring-4 ring-cyan-400/50 shadow-cyan-500/50 animate-bounce'
                  : voiceState === 'speaking'
                  ? 'bg-gradient-to-tr from-pink-500 to-purple-600 ring-4 ring-pink-400/50 shadow-pink-500/50 animate-pulse'
                  : 'bg-gradient-to-tr from-purple-600 via-indigo-600 to-pink-500 ring-4 ring-purple-500/30 shadow-purple-600/40 hover:scale-105'
              }`}
              title="Toggle Rafi Ai Assistant Voice Microphone"
              aria-label="Toggle Rafi Ai Assistant Voice Microphone"
            >
              {voiceState === 'listening' ? (
                <Mic className="w-6 h-6 animate-pulse" />
              ) : (
                <Mic className="w-6 h-6" />
              )}
            </button>
          </div>

          {/* 4. Real Mobile Apps & Action Hub */}
          <button
            onClick={() => {
              setActiveTab('tools');
              playSound('pop');
            }}
            className={`flex flex-col items-center gap-1 transition-all ${
              activeTab === 'tools'
                ? 'text-indigo-300 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className={`p-1.5 rounded-xl ${activeTab === 'tools' ? 'bg-indigo-600/30' : ''}`}>
              <LayoutGrid className="w-5 h-5" />
            </div>
            <span className="text-[10px]">অ্যাপস ও কাজ</span>
          </button>

          {/* 5. Chat tab */}
          <button
            onClick={() => {
              setIsChatOpen(true);
              playSound('pop');
            }}
            className="flex flex-col items-center gap-1 text-slate-400 hover:text-slate-200 transition-all"
          >
            <div className="p-1.5 rounded-xl">
              <MessageSquare className="w-5 h-5" />
            </div>
            <span className="text-[10px]">Chat</span>
          </button>
        </div>
      </nav>

      {/* REAL ACTION MODALS */}
      <RealCameraModal
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        bossName={settings.bossName}
      />

      <RealMusicPlayerModal
        isOpen={isMusicOpen}
        onClose={() => setIsMusicOpen(false)}
        bossName={settings.bossName}
      />

      <RealNotesDrawer
        isOpen={isNotesOpen}
        onClose={() => setIsNotesOpen(false)}
        notes={notes}
        onAddNote={handleAddNote}
        onDeleteNote={handleDeleteNote}
        onSpeakNote={speakNusuReply}
        bossName={settings.bossName}
      />

      {/* COMPANION MODALS */}
      <ChatDrawer
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        messages={messages}
        onSendMessage={handleUserVoicePrompt}
        onSpeakText={speakNusuReply}
        onClearHistory={() => setMessages([])}
        voiceState={voiceState}
        onStartVoice={handleToggleMic}
        bossName={settings.bossName}
      />

      <MemoriesModal
        isOpen={isMemoriesOpen}
        onClose={() => setIsMemoriesOpen(false)}
        memories={memories}
        onAddMemory={(key, value) => {
          setMemories((prev) => [
            ...prev,
            { id: Date.now().toString(), key, value, category: 'personal' },
          ]);
        }}
        onDeleteMemory={(id) => {
          setMemories((prev) => prev.filter((m) => m.id !== id));
        }}
        onRecallVoice={handleRecallMemories}
      />

      <ScreenShareModal
        isOpen={isScreenShareOpen}
        onClose={() => setIsScreenShareOpen(false)}
        onAnalyzeScreen={handleAnalyzeScreen}
        isAnalyzing={isAnalyzingScreen}
        bossName={settings.bossName}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newVals) => setSettings((prev) => ({ ...prev, ...newVals }))}
        onTestVoice={handleTestVoice}
      />

      <ReferenceVideoModal
        isOpen={isVideoRefOpen}
        onClose={() => setIsVideoRefOpen(false)}
      />

    </div>
  );
}
